% Joint distribution of 2 folded normal random variables
function pdf = bivfnormpdf(X1, X2, M1, M2, COV)
% X > 0
M = [M1, M2];
X = [X1(:), X2(:)];

pdf = mvnpdf(X, M, COV) +...
      mvnpdf([-X(:,1), X(:,2)], M, COV) +...
      mvnpdf([X(:,1), -X(:,2)], M, COV) +...
      mvnpdf([-X(:,1), -X(:,2)], M, COV);              

pdf = reshape(pdf, size(X1));
