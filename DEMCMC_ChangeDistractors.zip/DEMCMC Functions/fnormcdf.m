% Folded normal cdf
function cdf = fnormcdf(x, m, s)

posterm = (x + m)./sqrt(2 * s.^2);
negterm = (x - m)./sqrt(2 * s.^2);
cdf = .5 * (erf(posterm) + erf(negterm));
