function pdf = getPriorDensity(varname, xval, hyperprior)
% See makePriorDistribution

switch varname
    case {'db', 'db1', 'db2', 'sp1', 'sp2', 'sp3', 'sp4',...
            'A', 'bMa1', 'bMa2', 'bMa1_2', 'bMa2_2', 'bMa1_3', 'bMa2_3', 'bMa1_4', 'bMa2_4',...
            's', 't0', 'pX', 'm', 'pSer', 'Aser', 'Apar', 'rmu', 'rSigma', 'Ls', 'Hs',...
            't0_2', 't0_3', 't0_4'}
        pdf = lognormpdf(xval, hyperprior(1), hyperprior(2));
end