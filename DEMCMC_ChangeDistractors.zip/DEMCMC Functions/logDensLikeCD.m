function [out, lnL] = logDensLikeCD(x, data, model, names)
% Organize parameters based on the model
% Use holmes PDA method to compute the likelihood for each data point
% Sum these loglikelihoods to compute the overall log likelihood
%
% 10-Nov-2022 DL>> Using mean of the dprimes is incorrect for sample size
% model. Use sqrt(v1^2+v2^2)

if ~isstruct(x) % Fitting using fminsearch
    % convert to structure
    x = cell2struct(mat2cell(x, ones(numel(x), 1), 1), names);
    mult = -1; 
else
     mult = 1; 
end

%% Set up the model
switch model
    case {'coactivemx'}
        flag = true;
        stoppingrule = 'mx';
%         fmodel = @simcoactive;
        fmodel = repmat({@simcoactive}, size(data.itemConditions, 1), 1);
    case {'coactivemn'}
        flag = true;
        stoppingrule = 'mn';
%         fmodel = @simcoactive;
        fmodel = repmat({@simcoactive}, size(data.itemConditions, 1), 1);
    case {'mixedSPst'}
        flag = false;
        stoppingrule = 'st';
%         fmodel = @simmixedSP;
        fmodel = repmat({@simmixedSP}, size(data.itemConditions, 1), 1);
    case {'mixedSerialC'}
        flag = false;
        stoppingrule = 'st';
%         fmodel = @simmixedSerialContaminant;
        fmodel = repmat({@simmixedSerialContaminant}, size(data.itemConditions, 1), 1);
    case {'mixedParallelC'}
        flag = false;
        stoppingrule = 'st';
%         fmodel = @simmixedParallelContaminant;
        fmodel = repmat({@simmixedParallelContaminant}, size(data.itemConditions, 1), 1);
    case {'serialAttentionShiftst'}
        flag = false;
        stoppingrule = 'st';
        fmodel = @simserialAttentionShift;
        fmodel = repmat({@simserialAttentionShift}, size(data.itemConditions, 1), 1);        
    case {'parallel_boundaryst', 'indsamplesizest', 'parallelHL_boundaryst'}
        flag = false;
        stoppingrule = 'st';
        fmodel = repmat({@simparallel}, size(data.itemConditions, 1), 1);
        fmodel(data.itemConditions(:,strcmp(data.itemConditionCols, 'setsize')) == 1) = {@simcoactive};
    case {'coactive_boundarymn', 'coactiveHL_boundarymn'}
        flag = true;
        stoppingrule = 'mn';
%         fmodel = @simcoactive;
        fmodel = repmat({@simcoactive}, size(data.itemConditions, 1), 1);
    case {'samplesizest', 'samplesize_boundaryst', 'samplesize_ndtst'}
        stoppingrule = 'st';
%         fmodel = @simcoactive;
        fmodel = repmat({@simcoactive}, size(data.itemConditions, 1), 1);
    otherwise
        flag = false;
        stoppingrule = model(end-1:end);
        eval(sprintf('basefmodel = @sim%s;', model(1:end-2)))
        fmodel = repmat({basefmodel}, size(data.itemConditions, 1), 1);
        fmodel(data.itemConditions(:,strcmp(data.itemConditionCols, 'setsize')) == 1) = {@simcoactive};        
end
rule = stoppingrule;

%% Use GRT to get drift rates
x.bMa1 = exp(x.bMa1);
x.bMa2 = exp(x.bMa2);
x.s = exp(x.s);
x.t0 = exp(x.t0);

%% For all models except...
% includes parallel ST
switch model
    case {'parallel_boundaryst', 'coactive_boundarymn'}
        x.db1 = logit(x.db1, 'inverse'); % Boundary on dimension 1
        x.db2 = logit(x.db2, 'inverse'); % Boundary on dimension 2
        
        % Variability varies with set size but is equal across changes of different strength
        x.sp1 = exp(x.sp1); x.sp2 = exp(x.sp2); x.sp3 = exp(x.sp3); x.sp4 = exp(x.sp4);
        
        vc = grt_cd_dbt_lauren(data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})),...
            [x.db1, x.db2], [x.sp1, x.sp2, x.sp3, x.sp4],...
            data.itemConditions(:,mstrfind(data.itemConditionCols, {'setsize'})),...
            flag, rule); % Drift rate for the "Same" accumulator
        nitems = size(data.itemConditions,1);
        
        x.A = exp(x.A);
        
        % Response caution varies with set size
        x.('bMa1_2') = exp(x.bMa1_2); x.('bMa2_2') = exp(x.bMa2_2);
        x.('bMa1_3') = exp(x.bMa1_3); x.('bMa2_3') = exp(x.bMa2_3);
        x.('bMa1_4') = exp(x.bMa1_4); x.('bMa2_4') = exp(x.bMa2_4);
    case {'parallelHL_boundaryst', 'coactiveHL_boundarymn'}
        strengthParms = [0, exp([x.Ls, x.Hs])]; % Get strength parameters        
        
        x.db1 = logit(x.db1, 'inverse'); % Boundary on dimension 1
        x.db2 = logit(x.db2, 'inverse'); % Boundary on dimension 2
        
        % Variability varies with set size but is equal across changes of different strength
        x.sp1 = exp(x.sp1); x.sp2 = exp(x.sp2); x.sp3 = exp(x.sp3); x.sp4 = exp(x.sp4);
        
        vc = grt_cd_dbt_lauren(strengthParms(data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})) + 1),...
            [x.db1, x.db2], [x.sp1, x.sp2, x.sp3, x.sp4],...
            data.itemConditions(:,mstrfind(data.itemConditionCols, {'setsize'})),...
            flag, rule); % Drift rate for the "Same" accumulator
        nitems = size(data.itemConditions,1);
        
        x.A = exp(x.A);
        
        % Response caution varies with set size
        x.('bMa1_2') = exp(x.bMa1_2); x.('bMa2_2') = exp(x.bMa2_2);
        x.('bMa1_3') = exp(x.bMa1_3); x.('bMa2_3') = exp(x.bMa2_3);
        x.('bMa1_4') = exp(x.bMa1_4); x.('bMa2_4') = exp(x.bMa2_4);        
    case {'samplesizest', 'samplesize_boundaryst', 'samplesize_ndtst'}
        strengthParms = [0, exp([x.Ls, x.Hs])]; % Get strength parameters
        x.db1 = exp(x.db); % Single boundary between No change and L & between No change and H
        %         x.db2 = x.db1 + exp(x.db2); % Boundary between No change and H (must be greater than x.db1)
        
        % Mean item location varies with strength
        setSize = data.itemConditions(:,strcmp(data.itemConditionCols, 'setsize'));
        nChanges= data.itemConditions(:,strcmp(data.itemConditionCols, 'nChanges'));
        
        locs = data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})); % Only one change strength is needed for sample size model

        csm = strengthParms(locs+1); % change strength mean
%         csm(nChanges == 2, 1) = mean(csm(nChanges == 2, :), 2); % Avg change strength when there are 2 changes
%         changeStrengthMean = csm(:,1);
        
        % Variability varies with strength
        %         x.sp1 = exp(x.sp1); % Low strength
        %         x.sp2 = exp(x.sp2); % High strength
        
        % Variability always equals 1
        x.sp1 = 1;
        
%         dprime = sqrt(nChanges) .* changeStrengthMean ./ sqrt(setSize);
        dprime = sqrt(csm(:,1).^2 + csm(:,2).^2) ./ sqrt(setSize); 
        
        % Compute pChangeResponse from sample size model
        vc = grt_cd_dbt_samplesize(dprime, x.db1, x.sp1); % Drift rate for the "Same" accumulator
        nitems = size(data.itemConditions,1);
        x.A = exp(x.A);

        if strcmp(model, 'samplesize_boundaryst')
            % Response caution varies with set size
            x.('bMa1_2') = exp(x.bMa1_2); x.('bMa2_2') = exp(x.bMa2_2);
            x.('bMa1_3') = exp(x.bMa1_3); x.('bMa2_3') = exp(x.bMa2_3);
            x.('bMa1_4') = exp(x.bMa1_4); x.('bMa2_4') = exp(x.bMa2_4);
        elseif strcmp(model, 'samplesize_ndtst')
            x.('t0_2') = exp(x.t0_2);
            x.('t0_3') = exp(x.t0_3);
            x.('t0_4') = exp(x.t0_4);
        end

    case {'indsamplesizest'}
        strengthParms = [0, exp([x.Ls, x.Hs])]; % Get strength parameters
        x.db1 = exp(x.db); % Single boundary between No change and L & between No change and H
        
        % Variability always equals 1
        x.sp1 = 1;

        % Mean item location varies with strength
        setSize = data.itemConditions(:,strcmp(data.itemConditionCols, 'setsize'));
        nChanges= data.itemConditions(:,strcmp(data.itemConditionCols, 'nChanges'));

        locs = data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})); % Only one change strength is needed for sample size model
        csm = strengthParms(locs+1); % change strength mean
        csm(nChanges == 2, :) = sort(csm(nChanges == 2, :), 2); % Sort change strength so the Low is always in channel 1
        
        dprime = nan(size(csm,1), 2);
        dprime(setSize <= 2, :) = csm(setSize<= 2, :);
        dprime(setSize == 3,:) = [csm(setSize == 3,1)./sqrt(2), csm(setSize==3,2)];
        dprime(setSize == 4,:) = [csm(setSize == 4,1)./sqrt(2), csm(setSize==4,2)./sqrt(2)];

        vc(:,1) = grt_cd_dbt_samplesize(dprime(:,1), x.db1, x.sp1); % Drift rate for the "Same" accumulator
        vc(:,2) = grt_cd_dbt_samplesize(dprime(:,2), x.db1, x.sp1); % Drift rate for the "Same" accumulator
        
        nitems = size(data.itemConditions,1);
        
        x.A = exp(x.A);
        
        % Response caution varies with set size
        x.('bMa1_2') = exp(x.bMa1_2); x.('bMa2_2') = exp(x.bMa2_2);
        x.('bMa1_3') = exp(x.bMa1_3); x.('bMa2_3') = exp(x.bMa2_3);
        x.('bMa1_4') = exp(x.bMa1_4); x.('bMa2_4') = exp(x.bMa2_4);
 
    case {'parallelHLst', 'coactiveHLmn'}
        strengthParms = [0, exp([x.Ls, x.Hs])]; % Get strength parameters
        
        x.db1 = logit(x.db1, 'inverse'); % Boundary on dimension 1
        x.db2 = logit(x.db2, 'inverse'); % Boundary on dimension 2
        
        % Variability varies with set size but is equal across changes of different strength
        x.sp1 = exp(x.sp1); x.sp2 = exp(x.sp2); x.sp3 = exp(x.sp3); x.sp4 = exp(x.sp4);
        
        x.A = exp(x.A);
        vc = grt_cd_dbt_lauren(strengthParms(data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})) + 1),...
            [x.db1, x.db2], [x.sp1, x.sp2, x.sp3, x.sp4],...
            data.itemConditions(:,mstrfind(data.itemConditionCols, {'setsize'})),...
            flag, rule); % Drift rate for the "Same" accumulator
        nitems = size(data.itemConditions,1);        
        
    otherwise
        x.db1 = logit(x.db1, 'inverse'); % Boundary on dimension 1
        x.db2 = logit(x.db2, 'inverse'); % Boundary on dimension 2
        
        % Variability varies with set size but is equal across changes of different strength
        x.sp1 = exp(x.sp1); x.sp2 = exp(x.sp2); x.sp3 = exp(x.sp3); x.sp4 = exp(x.sp4);
        
        x.A = exp(x.A);
        vc = grt_cd_dbt_lauren(data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})),...
            [x.db1, x.db2], [x.sp1, x.sp2, x.sp3, x.sp4],...
            data.itemConditions(:,mstrfind(data.itemConditionCols, {'setsize'})),...
            flag, rule); % Drift rate for the "Same" accumulator
        nitems = size(data.itemConditions,1);
end

%% Organize the parameters for the model and loop through items
for i = 1:nitems
    switch model
        case {'parallel_boundaryst', 'coactive_boundarymn',...
                'parallelHL_boundaryst', 'coactiveHL_boundarymn',...
                'samplesize_boundaryst', 'indsamplesizest'}
            parms(i).('vc') = vc(i,:);
            parms(i).('A') = x.('A');
            
            switch data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize'))
                case 1
                    parms(i).('bMa') = [x.('bMa1'), x.('bMa2')];
                case 2
                    parms(i).('bMa') = [x.('bMa1_2'), x.('bMa2_2')];
                case 3
                    parms(i).('bMa') = [x.('bMa1_3'), x.('bMa2_3')];
                case 4
                    parms(i).('bMa') = [x.('bMa1_4'), x.('bMa2_4')];
            end
            parms(i).('t0') = x.('t0');
        case {'samplesize_ndtst'}
            parms(i).('vc') = vc(i,:);
            parms(i).('A') = x.('A');
            parms(i).('bMa') = [x.('bMa1'), x.('bMa2')];
            switch data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize'))
                case 1
                    parms(i).('t0') = x.('t0');
                case 2
                    parms(i).('t0') = x.('t0_2');
                case 3
                    parms(i).('t0') = x.('t0_3');
                case 4
                    parms(i).('t0') = x.('t0_4');
            end           
        otherwise
            parms(i).('vc') = vc(i,:);
            parms(i).('A') = x.('A');
            parms(i).('bMa') = [x.('bMa1'), x.('bMa2')];
            parms(i).('t0') = x.('t0');
    end
    parms(i).('s') = x.('s');
end

%% Loop

fit = nan(nitems,1);
% parfor i = 1:nitems
for i = 1:nitems
    iparms = parms(i);
    
    % Set up the data for the current item
    idata = [data.resp(data.item == i), data.rt(data.item == i)];
    
    % Get likelihood for each data point
    lik = pdaholmes(fmodel{i}, 5e4, idata, iparms, stoppingrule);
    lik(lik == 0) = 1e-10;
    lnL{i} = lik;
    % Sum over all data points
    fit(i) = sum(log(lik));
end
out = mult * sum(fit);