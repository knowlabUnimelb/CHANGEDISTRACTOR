function transformedSamples = transformSamples(theta, data)

names = fieldnames(theta);
for i = 1:numel(names)
    switch names{i}
        case 'db1'
            transformedSamples.(names{i}) =...
                (logit(theta.(names{i}), 'inverse'));
        case 'db2'
            transformedSamples.(names{i}) =...
                (logit(theta.(names{i}), 'inverse'));
        case {'db', 'sp1', 'sp2', 'sp3', 'sp4',...
                'A', 'bMa1', 'bMa2', 'bMa1_2', 'bMa2_2', 'bMa1_3', 'bMa2_3', 'bMa1_4', 'bMa2_4',...
                's', 't0', 'm', 'Aser', 'Apar', 'rmu', 'rSigma', 'Ls', 'Hs', 't0_2', 't0_3', 't0_4'}
            transformedSamples.(names{i}) = exp(theta.(names{i}));
        case {'pX', 'pSer'}
            transformedSamples.(names{i}) = logit(theta.(names{i}), 'inverse');
    end
       
end