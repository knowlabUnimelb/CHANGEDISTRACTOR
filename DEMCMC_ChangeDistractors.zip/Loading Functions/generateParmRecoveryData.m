clear all
clc


[data, parms] = generateTestData(model, 350, data.stimloc, (data.stimloc(6,1)-data.stimloc(7,1))/2)