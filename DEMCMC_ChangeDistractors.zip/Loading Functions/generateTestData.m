function [outdata, parms] = generateTestData(model, nd, data, varargin)

nParms = (nargin-3)/2;

cnt = 1;
for id = 1:nParms
    parms.(varargin{cnt}) = varargin{cnt+1};
    cnt = cnt + 2; 
end

% optargs = {1.5, 1.5, 1, 1, 1, 1, .75, .25, .25, .1, .3, .5, 1, .5, .75, .75, nan, 0, 0};
% newVals = cellfun(@(x) ~isempty(x), varargin); % skip any new inputs if they are empty
% optargs(newVals) = varargin(newVals); % now put these defaults into the valuesToUse cell array, and overwrite the ones specified in varargin.
% [db1, db2, sp1, sp2, sp3, sp4, A, bMa1, bMa2, s, t0, pX, m, pSer, Aser, Apar, obs, rmu, rSigma] = optargs{:}; % Place optional args in memorable variable names

% parms = struct('db1', db1, 'db2', db2,...
%                'sp1', sp1, 'sp2', sp2, 'sp3', sp3, 'sp4', sp4,...
%                'A', A, 'bMa1', bMa1, 'bMa2', bMa2, 's', s, 't0', t0,...
%                'pX', pX, 'm', m, 'pSer', pSer, 'Aser', Aser, 'Apar', Apar,...
%                'rmu', rmu, 'rSigma', rSigma);

%% Parameters
stoppingrule = model(end-1:end);

if ~any(strcmp(model, {'samplesizest', 'samplesize_boundaryst', 'samplesize_ndtst', 'indsamplesizest'}))
    db = [parms.db1, parms.db2];
    sp = [parms.sp1, parms.sp2, parms.sp3, parms.sp4];
elseif strcmp(model, 'indsamplesizest')
    db1 = parms.db;
    sp1 = 1; 
else
    db1 = parms.db;
    sp1 = 1; 
end

flag = false;
rule = '';

switch model
    case {'coactivemx'}
        flag = true;
        rule = 'mx';
    case {'coactivemn', 'coactive_boundarymn'}
        flag = true;
        rule = 'mn';
end

stim = data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'}));

if ~any(strcmp(model, {'samplesizest', 'samplesize_boundaryst', 'samplesize_ndtst', 'indsamplesizest'}))
    vc = grt_cd_dbt_lauren(stim,...
        db, sp,...
        data.itemConditions(:,mstrfind(data.itemConditionCols, {'setsize'})),...
        flag, rule); % Drift rate for the "A" accumulator
elseif strcmp(model, 'mixedSPst')
    vc = grt_cd_dbt_lauren(stim,...
        db, sp,...
        data.itemConditions(:,mstrfind(data.itemConditionCols, {'setsize'})),...
        flag, rule); % Drift rate for the "A" accumulator
    servc = vc;
    parvc = grt_cd_dbt_lauren(stim, db, parms.m*sp, flag, rule); % Drift rate for the "A" accumulator 
elseif strcmp(model, 'indsamplesizest')
    strengthParms = [0, parms.Ls, parms.Hs]; % Get strength parameters

    % Mean item location varies with strength
    setSize = data.itemConditions(:,strcmp(data.itemConditionCols, 'setsize'));
    nChanges= data.itemConditions(:,strcmp(data.itemConditionCols, 'nChanges'));

    locs = data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})); % Only one change strength is needed for sample size model
    csm = strengthParms(locs+1); % change strength mean
    csm(nChanges == 2, :) = sort(csm(nChanges == 2, :), 2); % Sort change strength so the Low is always in channel 1

    dprime = nan(size(csm,1), 2);
    dprime(setSize <= 2, :) = csm(setSize<= 2, :);
    dprime(setSize == 3,:) = [csm(setSize == 3,1)./2, csm(setSize==3,2)];
    dprime(setSize == 4,:) = [csm(setSize == 4,1)./2, csm(setSize==4,2)./2];

    vc(:,1) = grt_cd_dbt_samplesize(dprime(:,1), db1, sp1); % Drift rate for the "Same" accumulator
    vc(:,2) = grt_cd_dbt_samplesize(dprime(:,2), db1, sp1); % Drift rate for the "Same" accumulator
else % sample size model
    strengthParms = [0, parms.Ls, parms.Hs]; % Get strength parameters
       
    % Mean item location varies with strength
    setSize = data.itemConditions(:,strcmp(data.itemConditionCols, 'setsize'));
    nChanges= data.itemConditions(:,strcmp(data.itemConditionCols, 'nChanges'));

    locs = data.itemConditions(:,mstrfind(data.itemConditionCols, {'change1', 'change2'})); % Only one change strength is needed for sample size model
    csm = strengthParms(locs+1); % change strength mean
    csm(nChanges == 2, 1) = mean(csm(nChanges == 2, :), 2); % Avg change strength when there are 2 changes
    changeStrengthMean = csm(:,1);

    dprime = sqrt(nChanges) .* changeStrengthMean ./ sqrt(setSize);
    vc = grt_cd_dbt_samplesize(dprime, db1, sp1); % Drift rate for the "Same" accumulator
end

%% Simulate data
n.items = size(vc,1);

if strcmp(model, 'samplesize_ndtst')
    t0set = [parms.t0, parms.t0_2, parms.t0_3, parms.t0_4];
elseif any(strcmp(model, {'samplesize_boundaryst', 'parallel_boundaryst'}))
    bMaset = [parms.bMa1  , parms.bMa2;
              parms.bMa1_2, parms.bMa2_2;
              parms.bMa1_3, parms.bMa2_3;
              parms.bMa1_4, parms.bMa2_4];
end

outdata = struct('rt', [], 'resp', [], 'item', [], 'stimloc', stim);
for i = 1:n.items
    switch model 
        case {'serialst', 'serialrb'}
            simparms = struct('vc', vc(i,:), 'A', parms.A, 'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0, 'pX', parms.pX);
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', model(1:end-2)))
        case {'serialAttentionShiftst'}
            simparms = struct('vc', vc(i,:), 'A', parms.A, 'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0, 'pX', parms.pX, 'rmu', parms.rmu, 'rSigma', parms.rSigma);
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', model(1:end-2)))
        case {'mixedSPst'}
            simparms = struct('servc', servc(i,:), 'parvc', parvc(i,:), 'Aser', parms.Aser, 'Apar', parms.Apar, 'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0, 'pX', parms.pX, 'pSer', parms.pSer);
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', model(1:end-2)))
        case {'mixedSerialC'}
            simparms = struct('servc', vc(i,:), 'Aser', parms.Aser, 'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0, 'pX', parms.pX, 'pSer', parms.pSer, 'maxRT', max(obs.rt), 'pResp', mean(obs.resp(obs.item == i) == 1));
            fmodel = 'mixedSerialContaminantst';
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))
        case {'mixedParallelC'}
            simparms = struct('parvc', vc(i,:), 'Apar', parms.Apar, 'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0, 'pPar', parms.pSer, 'maxRT', max(obs.rt), 'pResp', mean(obs.resp(obs.item == i) == 1));
            fmodel = 'mixedParallelContaminantst';
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))
        case {'parallel_boundaryst'}
            simparms = struct('vc', vc(i,:), 'A', parms.A,...
                'bMa', bMaset(data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')),:), 's', parms.s, 't0', parms.t0);
            if data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')) > 1
                fmodel = [strtok(model, '_'), 'st'];
                eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))
            else
                fmodel = 'coactivemn';
                eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))
            end
        case {'indsamplesizest'}
            bMa = [parms.bMa1, parms.bMa2; 
                   parms.bMa1_2, parms.bMa2_2;
                   parms.bMa1_3, parms.bMa2_3;
                   parms.bMa1_4, parms.bMa2_4];
            simparms = struct('vc', vc(i,:), 'A', parms.A, 'bMa', bMa(data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')), :),...
                's', parms.s, 't0', parms.t0);
            if data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')) > 1
                model = 'parallelst';
                eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', model(1:end-2)))
            else
                fmodel = 'coactivemn';
                eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))     
            end            
        case {'coactive_boundarymn'}
            bMa = [parms.bMa1, parms.bMa2; 
                   parms.bMa1_2, parms.bMa2_2;
                   parms.bMa1_3, parms.bMa2_3;
                   parms.bMa1_4, parms.bMa2_4];
            simparms = struct('vc', vc(i,:), 'A', parms.A, 'bMa', bMa(data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')), :), 's', parms.s, 't0', parms.t0 );
            fmodel = 'coactivemn';
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))     
        case {'samplesizest'}
            simparms = struct('vc', vc(i,:), 'A', parms.A,...
                'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0);
            fmodel = 'coactivemn';
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))
        case {'samplesize_boundaryst'}
            simparms = struct('vc', vc(i,:), 'A', parms.A,...
                'bMa', bMaset(data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')),:), 's', parms.s, 't0', parms.t0);
            fmodel = 'coactivemn';
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))            
        case {'samplesize_ndtst'}
            simparms = struct('vc', vc(i,:), 'A', parms.A,...
                'bMa', [parms.bMa1, parms.bMa2], 's', parms.s,...
                't0', t0set(data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize'))));
            fmodel = 'coactivemn';
            eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))            
        otherwise
            simparms = struct('vc', vc(i,:), 'A', parms.A, 'bMa', [parms.bMa1, parms.bMa2], 's', parms.s, 't0', parms.t0);

            if data.itemConditions(i, strcmp(data.itemConditionCols, 'setsize')) > 1
                eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', model(1:end-2)))
            else
                fmodel = 'coactivemn';
                eval(sprintf('[rt, resp] = sim%s(nd, simparms, stoppingrule);', fmodel(1:end-2)))     
            end
    end
    
    outdata.rt = [outdata.rt; rt];
    outdata.resp = [outdata.resp; resp];
    outdata.item = [outdata.item; i * ones(nd, 1)];
end

maxrt = 10;
outdata.resp(outdata.rt > maxrt) = [];
outdata.item(outdata.rt > maxrt) = [];
outdata.rt(outdata.rt   > maxrt) = [];