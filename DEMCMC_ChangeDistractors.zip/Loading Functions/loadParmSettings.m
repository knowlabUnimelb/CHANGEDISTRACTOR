function [parms, hyperparms, thetaprior] = loadParmSettings(model)
% All parameters are transformed to the real line and then transformed back
% to their appropriate settings

%% GRT parms 
% The model assumes that the evidence for a change can be modelled as a
% folded normal distribution over the absolute difference values. Changes
% can therefore have mean absolute values of 0, 1, or 2
% 
% A decision boundary is established for each of the two possible changes.
% Differences across locations are ignored (for now)
%
% The variability of the absolute difference signal. This can represent the
% influence of the decay of the first item, disruption due to the mask, and
% effects of set size. E.g., additional distractors should be expected to
% increase the variability with which the change magnitude is represented.
%
% Annie's data show that sp is roughly the same across the left and right
% locations. It was important in that study to estimate different variances
% to allow for there to be a difference between the dark and light dots.
% In Lauren's study, the dot could be dark or light at any location. So we
% ignore location and just focus on the variability of change 1 and change
% 2

%% Sample size change strengths
Ls = log(1);
Ls_mu = log(1); Ls_sigma = .5;

Hs = log(2);
Hs_mu = log(2); Hs_sigma = .5;

%% Decision boundary
% Set halfway between a null and low change, db1 = .5; 
db    = log(.5); 
db_mu = log(.5); db_sigma = .5;

% Set halfway between a null and low change, db1 = .5; 
% logit(db1) = 0
db1    = 0; 
db1_mu = 0; db1_sigma = .5;

% Set halfway between a null and low change, db2 = .5; 
% logit(db2) = 0
db2    = 0;
db2_mu = 0; db2_sigma = .5;

%% Perceptual variability
% sp is constrained to be greater than 0
sp1 = log(.2);
sp1_mu = -1.5; sp1_sigma = .5;

sp2 = log(.2);
sp2_mu = -1.5; sp2_sigma = .5;

sp3 = log(.2);
sp3_mu = -1.5; sp3_sigma = .5;

sp4 = log(.2);
sp4_mu = -1.5; sp4_sigma = .5;

%% LBA parms
%% Startpoint
A    = log(.35);  
A_mu = log(.35); A_sigma = .2;

%% A boundary minus start point
bMa1 = log(.25); % Threshold minus startpoint
bMa1_mu = log(.25); bMa1_sigma = 1;

bMa1_2 = log(.25); % Threshold minus startpoint
bMa1_2_mu = log(.25); bMa1_2_sigma = 1;

bMa1_3 = log(.25); % Threshold minus startpoint
bMa1_3_mu = log(.25); bMa1_3_sigma = 1;

bMa1_4 = log(.25); % Threshold minus startpoint
bMa1_4_mu = log(.25); bMa1_4_sigma = 1;

%% B boundary minus start point
bMa2 = log(.25); % Threshold minus startpoint
bMa2_mu = log(.25); bMa2_sigma = 1;

bMa2_2 = log(.25); % Threshold minus startpoint
bMa2_2_mu = log(.25); bMa2_2_sigma = 1;

bMa2_3 = log(.25); % Threshold minus startpoint
bMa2_3_mu = log(.25); bMa2_3_sigma = 1;

bMa2_4 = log(.25); % Threshold minus startpoint
bMa2_4_mu = log(.25); bMa2_4_sigma = 1;

%% Drift rate variability
s   = log(.25);  % Drift variability
s_mu = log(.25); s_sigma = .5;

%% Non-decision time
t0    = log(.22);  
t0_mu = log(.22); t0_sigma = .2;

t0_2    = log(.22);  
t0_2_mu = log(.22); t0_2_sigma = .2;

t0_3    = log(.22);  
t0_3_mu = log(.22); t0_3_sigma = .2;

t0_4    = log(.22);  
t0_4_mu = log(.22); t0_4_sigma = .2;

%% pX
pX = logit(.5);
pX_mu = logit(.5); pX_sigma = 2;

%% m - Multiplier on perceptual variability
% With these settings, m can grow quite large
% m = log(1);
% m_mu = log(1); m_sigma = 2; 
m = log(1);
m_mu = log(1); m_sigma = .2; 

%% pSer 
pSer = logit(.5);
pSer_mu = logit(.5); pSer_sigma = 2;

%% Aser
Aser    = log(.35);  
Aser_mu = log(.35); Aser_sigma = .2;

%% Apar
Apar    = log(.35);  
Apar_mu = log(.35); Apar_sigma = .2;

%% Residual Attention shift distribution parameters
rmu = log(5);
rmu_mu = log(5); rmu_sigma = .2;

rSigma = log(.2);
rSigma_mu = log(.2); rSigma_sigma = .02;

%% Parm structure
% Set up structure which hold the parameters for that model (need
% one section for each model with different parameterization)
parms = struct(...
    'db1', db1,...
    'db2', db2,...
    'sp1', sp1,...
    'sp2', sp2,...
    'sp3', sp3,...
    'sp4', sp4,...    
    'A', A,...
    'bMa1', bMa1,...
    'bMa2', bMa2,...
    's', s,...
    't0', t0);

hyperparms = struct(...
    'db1_mu', db1_mu,...
    'db1_sigma', db1_sigma,...
    'db2_mu', db2_mu,...
    'db2_sigma', db2_sigma,...
    'sp1_mu', sp1_mu,...
    'sp1_sigma', sp1_sigma,...
    'sp2_mu', sp2_mu,...
    'sp2_sigma', sp2_sigma,...
    'sp3_mu', sp3_mu,...
    'sp3_sigma', sp3_sigma,...
    'sp4_mu', sp4_mu,...
    'sp4_sigma', sp4_sigma,...    
    'A_mu', A_mu,...
    'A_sigma', A_sigma,...
    'bMa1_mu', bMa1_mu,...
    'bMa1_sigma', bMa1_sigma,...
    'bMa2_mu', bMa2_mu,...
    'bMa2_sigma', bMa2_sigma,...
    's_mu', s_mu,...
    's_sigma', s_sigma,...
    't0_mu', t0_mu,...
    't0_sigma', t0_sigma);

% Each parameter has two hyperparms
thetaprior = [...
    db1_mu, db1_sigma;
    db2_mu, db2_sigma;
    sp1_mu, sp1_sigma;
    sp2_mu, sp2_sigma;
    sp3_mu, sp3_sigma;
    sp4_mu, sp4_sigma;    
    A_mu, A_sigma;
    bMa1_mu, bMa1_sigma;
    bMa2_mu, bMa2_sigma;
    s_mu, s_sigma;
    t0_mu, t0_sigma];

names = fieldnames(parms);
switch model
    case {'samplesizest'}
        parms = rmfield(parms, {'db1', 'db2', 'sp1', 'sp2', 'sp3', 'sp4'});
        parms = setfield(parms, 'db', db);
        parms = setfield(parms, 'Ls', Ls);
        parms = setfield(parms, 'Hs', Hs);
        hyperparms = rmfield(hyperparms, {'db1_mu', 'db1_sigma', 'db2_mu', 'db2_sigma', 'sp1_mu', 'sp1_sigma', 'sp2_mu', 'sp2_sigma', 'sp3_mu', 'sp3_sigma', 'sp4_mu', 'sp4_sigma'});
        hyperparms = setfield(hyperparms, 'db_mu', db_mu);
        hyperparms = setfield(hyperparms, 'db_sigma', db_sigma);
        hyperparms = setfield(hyperparms, 'Ls_mu', Ls_mu);
        hyperparms = setfield(hyperparms, 'Ls_sigma', Ls_sigma);
        hyperparms = setfield(hyperparms, 'Hs_mu', Hs_mu);
        hyperparms = setfield(hyperparms, 'Hs_sigma', Hs_sigma);
        
        thetaprior = [...
            A_mu, A_sigma;
            bMa1_mu, bMa1_sigma;
            bMa2_mu, bMa2_sigma;
            s_mu, s_sigma;
            t0_mu, t0_sigma;
            db_mu, db_sigma;
            Ls_mu, Ls_sigma;
            Hs_mu, Hs_sigma];
    case {'samplesize_ndtst'}
        parms = rmfield(parms, {'db1', 'db2', 'sp1', 'sp2', 'sp3', 'sp4'});
        parms = setfield(parms, 'db', db);
        parms = setfield(parms, 'Ls', Ls);
        parms = setfield(parms, 'Hs', Hs);
        parms = setfield(parms, 't0_2', t0_2);
        parms = setfield(parms, 't0_3', t0_3);
        parms = setfield(parms, 't0_4', t0_4);
        
        hyperparms = rmfield(hyperparms, {'db1_mu', 'db1_sigma', 'db2_mu', 'db2_sigma', 'sp1_mu', 'sp1_sigma', 'sp2_mu', 'sp2_sigma', 'sp3_mu', 'sp3_sigma', 'sp4_mu', 'sp4_sigma'});
        hyperparms = setfield(hyperparms, 'db_mu', db_mu);
        hyperparms = setfield(hyperparms, 'db_sigma', db_sigma);
        hyperparms = setfield(hyperparms, 'Ls_mu', Ls_mu);
        hyperparms = setfield(hyperparms, 'Ls_sigma', Ls_sigma);
        hyperparms = setfield(hyperparms, 'Hs_mu', Hs_mu);
        hyperparms = setfield(hyperparms, 'Hs_sigma', Hs_sigma);
        hyperparms = setfield(hyperparms, 't0_2_mu', t0_2_mu);
        hyperparms = setfield(hyperparms, 't0_2_sigma', t0_2_sigma);
        hyperparms = setfield(hyperparms, 't0_3_mu', t0_3_mu);
        hyperparms = setfield(hyperparms, 't0_3_sigma', t0_3_sigma);
        hyperparms = setfield(hyperparms, 't0_4_mu', t0_4_mu);
        hyperparms = setfield(hyperparms, 't0_4_sigma', t0_4_sigma);
        
        thetaprior = [...
            A_mu, A_sigma;
            bMa1_mu, bMa1_sigma;
            bMa2_mu, bMa2_sigma;
            s_mu, s_sigma;
            t0_mu, t0_sigma;
            db_mu, db_sigma;
            Ls_mu, Ls_sigma;
            Hs_mu, Hs_sigma;
            t0_2_mu, t0_2_sigma;
            t0_3_mu, t0_3_sigma;
            t0_4_mu, t0_4_sigma];
        
    case {'samplesize_boundaryst', 'indsamplesizest'}
        parms = rmfield(parms, {'db1', 'db2', 'sp1', 'sp2', 'sp3', 'sp4'});
        parms = setfield(parms, 'db', db);
        parms = setfield(parms, 'Ls', Ls);
        parms = setfield(parms, 'Hs', Hs);
        
        hyperparms = rmfield(hyperparms, {'db1_mu', 'db1_sigma', 'db2_mu', 'db2_sigma', 'sp1_mu', 'sp1_sigma', 'sp2_mu', 'sp2_sigma', 'sp3_mu', 'sp3_sigma', 'sp4_mu', 'sp4_sigma'});
        hyperparms = setfield(hyperparms, 'db_mu', db_mu);
        hyperparms = setfield(hyperparms, 'db_sigma', db_sigma);
        hyperparms = setfield(hyperparms, 'Ls_mu', Ls_mu);
        hyperparms = setfield(hyperparms, 'Ls_sigma', Ls_sigma);
        hyperparms = setfield(hyperparms, 'Hs_mu', Hs_mu);
        hyperparms = setfield(hyperparms, 'Hs_sigma', Hs_sigma);
        
        parms = setfield(parms, 'bMa1_2', bMa1_2);
        parms = setfield(parms, 'bMa1_3', bMa1_3);
        parms = setfield(parms, 'bMa1_4', bMa1_4);
        parms = setfield(parms, 'bMa2_2', bMa2_2);
        parms = setfield(parms, 'bMa2_3', bMa2_3);
        parms = setfield(parms, 'bMa2_4', bMa2_4);
        
        hyperparms = setfield(hyperparms, 'bMa1_2_mu', bMa1_2_mu);
        hyperparms = setfield(hyperparms, 'bMa1_2_sigma', bMa1_2_sigma);
        hyperparms = setfield(hyperparms, 'bMa1_3_mu', bMa1_3_mu);
        hyperparms = setfield(hyperparms, 'bMa1_3_sigma', bMa1_3_sigma);
        hyperparms = setfield(hyperparms, 'bMa1_4_mu', bMa1_4_mu);
        hyperparms = setfield(hyperparms, 'bMa1_4_sigma', bMa1_4_sigma);
        hyperparms = setfield(hyperparms, 'bMa2_2_mu', bMa2_2_mu);
        hyperparms = setfield(hyperparms, 'bMa2_2_sigma', bMa2_2_sigma); 
        hyperparms = setfield(hyperparms, 'bMa2_3_mu', bMa2_3_mu);
        hyperparms = setfield(hyperparms, 'bMa2_3_sigma', bMa2_3_sigma);
        hyperparms = setfield(hyperparms, 'bMa2_4_mu', bMa2_4_mu);
        hyperparms = setfield(hyperparms, 'bMa2_4_sigma', bMa2_4_sigma);        
        
        thetaprior = [...
            A_mu, A_sigma;
            bMa1_mu, bMa1_sigma;
            bMa2_mu, bMa2_sigma;
            s_mu, s_sigma;
            t0_mu, t0_sigma;
            db_mu, db_sigma;
            Ls_mu, Ls_sigma;
            Hs_mu, Hs_sigma; 
            bMa1_2_mu, bMa1_2_sigma;
            bMa1_3_mu, bMa1_3_sigma;
            bMa1_4_mu, bMa1_4_sigma;
            bMa2_2_mu, bMa2_2_sigma;
            bMa2_3_mu, bMa2_3_sigma;
            bMa2_4_mu, bMa2_4_sigma];
     case {'parallelHLst', 'coactiveHLmn'}
        parms = setfield(parms, 'Ls', Ls);
        parms = setfield(parms, 'Hs', Hs);    
        
        hyperparms = setfield(hyperparms, 'Ls_mu', Ls_mu);
        hyperparms = setfield(hyperparms, 'Ls_sigma', Ls_sigma);
        hyperparms = setfield(hyperparms, 'Hs_mu', Hs_mu);
        hyperparms = setfield(hyperparms, 'Hs_sigma', Hs_sigma);      
        
        thetaprior = [thetaprior;             
            Ls_mu, Ls_sigma;
            Hs_mu, Hs_sigma];          

    case {'parallelHL_boundaryst', 'coactiveHL_boundarymn'}
        parms = setfield(parms, 'Ls', Ls);
        parms = setfield(parms, 'Hs', Hs);        
        parms = setfield(parms, 'bMa1_2', bMa1_2);
        parms = setfield(parms, 'bMa1_3', bMa1_3);
        parms = setfield(parms, 'bMa1_4', bMa1_4);
        parms = setfield(parms, 'bMa2_2', bMa2_2);
        parms = setfield(parms, 'bMa2_3', bMa2_3);
        parms = setfield(parms, 'bMa2_4', bMa2_4);
        
        hyperparms = setfield(hyperparms, 'Ls_mu', Ls_mu);
        hyperparms = setfield(hyperparms, 'Ls_sigma', Ls_sigma);
        hyperparms = setfield(hyperparms, 'Hs_mu', Hs_mu);
        hyperparms = setfield(hyperparms, 'Hs_sigma', Hs_sigma);    
        hyperparms = setfield(hyperparms, 'bMa1_2_mu', bMa1_2_mu);
        hyperparms = setfield(hyperparms, 'bMa1_2_sigma', bMa1_2_sigma);
        hyperparms = setfield(hyperparms, 'bMa1_3_mu', bMa1_3_mu);
        hyperparms = setfield(hyperparms, 'bMa1_3_sigma', bMa1_3_sigma);
        hyperparms = setfield(hyperparms, 'bMa1_4_mu', bMa1_4_mu);
        hyperparms = setfield(hyperparms, 'bMa1_4_sigma', bMa1_4_sigma);
        hyperparms = setfield(hyperparms, 'bMa2_2_mu', bMa2_2_mu);
        hyperparms = setfield(hyperparms, 'bMa2_2_sigma', bMa2_2_sigma); 
        hyperparms = setfield(hyperparms, 'bMa2_3_mu', bMa2_3_mu);
        hyperparms = setfield(hyperparms, 'bMa2_3_sigma', bMa2_3_sigma);
        hyperparms = setfield(hyperparms, 'bMa2_4_mu', bMa2_4_mu);
        hyperparms = setfield(hyperparms, 'bMa2_4_sigma', bMa2_4_sigma);
    
        
        thetaprior = [thetaprior;             
            Ls_mu, Ls_sigma;
            Hs_mu, Hs_sigma; 
            bMa1_2_mu, bMa1_2_sigma;
            bMa1_3_mu, bMa1_3_sigma;
            bMa1_4_mu, bMa1_4_sigma;
            bMa2_2_mu, bMa2_2_sigma;
            bMa2_3_mu, bMa2_3_sigma;
            bMa2_4_mu, bMa2_4_sigma];
    case {'serialst', 'serialrb'}
        parms = setfield(parms, 'pX', pX);
        hyperparms = setfield(hyperparms, 'pX_mu', pX_mu);
        hyperparms = setfield(hyperparms, 'pX_sigma', pX_sigma);
        thetaprior = [thetaprior; pX_mu, pX_sigma];
    case 'mixedSPst'
        parms = rmfield(parms, 'A');
        parms = setfield(parms, 'pX', pX);
        parms = setfield(parms, 'm', m);
        parms = setfield(parms, 'pSer', pSer);
        parms = setfield(parms, 'Aser', Aser);
        parms = setfield(parms, 'Apar', Apar);
        hyperparms = setfield(hyperparms, 'pX_mu', pX_mu);
        hyperparms = setfield(hyperparms, 'pX_sigma', pX_sigma);        
        hyperparms = rmfield(hyperparms, 'A_mu');
        hyperparms = rmfield(hyperparms, 'A_sigma');
        hyperparms = setfield(hyperparms, 'm_mu', m_mu);
        hyperparms = setfield(hyperparms, 'm_sigma', m_sigma);
        hyperparms = setfield(hyperparms, 'pSer_mu', pSer_mu);
        hyperparms = setfield(hyperparms, 'pSer_sigma', pSer_sigma);
        hyperparms = setfield(hyperparms, 'Aser_mu', Aser_mu);
        hyperparms = setfield(hyperparms, 'Aser_sigma', Aser_sigma);
        hyperparms = setfield(hyperparms, 'Apar_mu', Apar_mu);
        hyperparms = setfield(hyperparms, 'Apar_sigma', Apar_sigma);
        thetaprior(strcmp(names, 'A'), :) = [];
        thetaprior = [thetaprior; pX_mu, pX_sigma; m_mu, m_sigma; pSer_mu, pSer_sigma; Aser_mu, Aser_sigma; Apar_mu, Apar_sigma];
    case 'mixedSerialC'
        parms = rmfield(parms, 'A');
        parms = setfield(parms, 'pX', pX);
        parms = setfield(parms, 'pSer', pSer);
        parms = setfield(parms, 'Aser', Aser);
        hyperparms = setfield(hyperparms, 'pX_mu', pX_mu);
        hyperparms = setfield(hyperparms, 'pX_sigma', pX_sigma);        
        hyperparms = rmfield(hyperparms, 'A_mu');
        hyperparms = rmfield(hyperparms, 'A_sigma');
        hyperparms = setfield(hyperparms, 'pSer_mu', pSer_mu);
        hyperparms = setfield(hyperparms, 'pSer_sigma', pSer_sigma);
        hyperparms = setfield(hyperparms, 'Aser_mu', Aser_mu);
        hyperparms = setfield(hyperparms, 'Aser_sigma', Aser_sigma);
        thetaprior(strcmp(names, 'A'), :) = [];
        thetaprior = [thetaprior; pX_mu, pX_sigma; pSer_mu, pSer_sigma; Aser_mu, Aser_sigma];
    case 'mixedParallelC'
        parms = rmfield(parms, 'A');
        parms = setfield(parms, 'pSer', pSer);
        parms = setfield(parms, 'Apar', Apar);
        hyperparms = rmfield(hyperparms, 'A_mu');
        hyperparms = rmfield(hyperparms, 'A_sigma');
        hyperparms = setfield(hyperparms, 'pSer_mu', pSer_mu);
        hyperparms = setfield(hyperparms, 'pSer_sigma', pSer_sigma);
        hyperparms = setfield(hyperparms, 'Apar_mu', Apar_mu);
        hyperparms = setfield(hyperparms, 'Apar_sigma', Apar_sigma);
        thetaprior(strcmp(names, 'A'), :) = [];
        thetaprior = [thetaprior; pSer_mu, pSer_sigma; Apar_mu, Apar_sigma]; 
    case 'serialAttentionShiftst'
        parms = setfield(parms, 'pX', pX);
        parms = setfield(parms, 'rmu', rmu);
        parms = setfield(parms, 'rSigma', rSigma);
        hyperparms = setfield(hyperparms, 'pX_mu', pX_mu);
        hyperparms = setfield(hyperparms, 'pX_sigma', pX_sigma);
        hyperparms = setfield(hyperparms, 'rmu_mu', rmu_mu);
        hyperparms = setfield(hyperparms, 'rmu_sigma', rmu_sigma);
        hyperparms = setfield(hyperparms, 'rSigma_mu', rSigma_mu);
        hyperparms = setfield(hyperparms, 'rSigma_sigma', rSigma_sigma);
        thetaprior = [thetaprior; pX_mu, pX_sigma; rmu_mu, rmu_sigma; rSigma_mu, rSigma_sigma];
end