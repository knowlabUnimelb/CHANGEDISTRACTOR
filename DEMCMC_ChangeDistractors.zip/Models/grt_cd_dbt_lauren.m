% GRT for change detection
% Returns p(same)
%
% Compute drift rate, p(Step to Different), given dimension boundaries, 
% item locations, and standard deviations
%
% item locations are used to compute differences
function [p] = grt_cd_dbt_lauren(x, dx, sx, ss, coactive, rule)

% x  = [2   1 ];      % absolute difference on [dimx dimy] 
% dx = [.5  .6];      % [bndx bndy] between absolute difference distributions on dimx and dimy
% sx = [1, 1.2, 1.4, 1.5];     % [sigma_1 sigma_2 sigma_3 sigma_4] standard deviations of absolute
% differences for each set size
% ss = [1, 2, 3, 4]   % set size

if ~coactive
    DX = ones(size(x,1),1) * dx;
    SX = sx(ss);
  
    p = 1 - fnormcdf(DX, x, [SX' SX']);   % Folded normal cdf
%     p(zx < 0) = 1 - p(zx < 0); % Convert to p(different)

    
    % Truncate drift rate
    p(p<.00001) = .00001;
    p(p>.99999) = .99999;
else
    %   B | D
    %  -------
    %   A | C

    %% Slow method - but could handle violations of perceptual independence
    %    % Check positive semi-definiteness
    %    [~,err] = cholcov(diag(sx.^2),0);
    %    if err~=0
    %        warning('Covariance matrix not positive definate. Likely cause is that the variances have grown unusually large.');
    %        save errortemp
    %    end
    %
    %    aRegion = [   0      0; dx(1) dx(2)];
    %    bRegion = [   0  dx(2); dx(1)   inf];
    %    cRegion = [dx(1)     0;   inf dx(2)];
    %    dRegion = [dx(1) dx(2);   inf   inf];
    %
    %    for i = 1:size(x,1)
    %        fun = @(a, b)(bivfnormpdf(a, b, x(i,1), x(i,2), diag(sx.^2)));
    %
    %        % You never need to integrate a [a = 1 - (b + c + d)]
    %        %    a = integral2(fun, aRegion(1,1), aRegion(2,1), aRegion(1,2), aRegion(2,2));
    %
    %        % You always need to integrate d
    %        d = integral2(fun, dRegion(1,1), dRegion(2,1), dRegion(1,2), dRegion(2,2));
    %        switch rule
    %            case 'min'
    %                % You sometimes need to integrate b, c
    %                b = integral2(fun, bRegion(1,1), bRegion(2,1), bRegion(1,2), bRegion(2,2));
    %                c = integral2(fun, cRegion(1,1), cRegion(2,1), cRegion(1,2), cRegion(2,2));
    %                p(i,1) = b + c + d;
    %            case 'max'
    %                p(i,1) = d;
    %        end
    %    end
    
    %% Fast method
    DX = ones(size(x,1),1) * dx;
%     SX = ones(size(x,1),1) * sx;
  
%     ip = 1 - fnormcdf(DX, x, SX);   % Folded normal cdf
    SX = sx(ss);
    ip = 1 - fnormcdf(DX, x, [SX' SX']);   % Folded normal cdf
    
    %   B | D
    %  -------
    %   A | C
    
    switch rule
        case 'mn'
%             p = ip(:,1) .* ip(:,2) +...         % D
%                 ip(:,1) .* (1 - ip(:,2)) + ...  % C
%                 (1 - ip(:,1)) .* ip(:,2);       % B

            p = 1 - (1-ip(:,1)) .* (1 - ip(:,2)); % 1 minus region A
        case 'mx'
            p = ip(:,1) .* ip(:,2);             % D
    end
    
   % Truncate drift rate
    p(p<.00001) = .00001;
    p(p>.99999) = .99999;
end
% Drift above is p(Diff)

p = 1 - p; % Convert to p(Same)