% GRT for change detection
% Returns p(same) 
%
% Compute drift rate, p(Step to Same boundary), given dimension boundaries, 
% item locations, and standard deviations
%
% item locations are differences from no change (which has a mean of 0)

function [p] = grt_cd_dbt_samplesize(x, dx, sx)

DX = ones(size(x,1),1) * dx;
SX = ones(size(x,1),1) * sx;

p = fnormcdf(DX, x, SX);   % Folded normal cdf

% Truncate drift rate
p(p<.00001) = .00001;
p(p>.99999) = .99999;