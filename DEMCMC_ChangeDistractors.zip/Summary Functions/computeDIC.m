function [dic, dev_avg, pd] = computeDIC(model, data, logtheta, weight, version, idx)

%% Wikipedia method
% dev = -2 * weight(:);
% dev_hat = mean(dev);
% 
% avgparms = [];
% names = fieldnames(logtheta);
% for i = 1:numel(names)
%     temp = logtheta.(names{i});
%     temp = temp(:,idx);
%     eval(sprintf('%s = mean(temp(:));', names{i}));
%     eval(sprintf('avgparms = setfield(avgparms, names{i}, %s);', names{i}));
% end
% 
% % Compute loglikelihood for average sample
% if version == 1
%     avglnL = logDensLikeCD_dic(avgparms, data, model);
%     dev_avg = -2 * avglnL;
%     pd = dev_hat - dev_avg;
% else
%     pd = var(dev)/2;
% end
% dic = dev_hat + pd;

%% Gelman method
avgparms = [];
names = fieldnames(logtheta);
for i = 1:numel(names)
    temp = logtheta.(names{i});
    temp = temp(:,idx);
    eval(sprintf('%s = mean(temp(:));', names{i}));
    eval(sprintf('avgparms = setfield(avgparms, names{i}, %s);', names{i}));
end
dev_avg = logDensLikeCD(avgparms, data, model);

if version == 1
   pd = 2 * (dev_avg - mean(weight(:))); 
else
   pd = 2 * var(weight(:));
end
dic = -2 * (dev_avg - pd);