function [WAIC, lppd, pwaic] = computeWAIC(data, logtheta, model, n, version)

% My original code
names = fieldnames(logtheta);
psamples = round(1 * n.mcsamples);

for midx = 1:psamples
    % Sample parameters
    for iidx = 1:numel(names);
        use.theta.(names{iidx}) = logtheta.(names{iidx})(datasample(1:n.chains, 1), datasample(n.burnin+1:n.mc, 1));             % Get parms from current chain
    end
    
    % Get likelihood for each item
    % Note: logDensLikeLR transforms parameters back from log
    [~, lnL] = logDensLikeLR_dic(use.theta, data, model);

    % Convert to mat from cel
    lnl(:,midx) = cell2mat(lnL');
end

% lppd = sum(log(sum(exp(lnl), 2)./psamples));
lppd = sum(log(mean(exp(lnl), 2)));
if version == 1
    pwaic = 2 * sum(log(sum(exp(lnl), 2)./psamples) - sum(lnl,2)./psamples);
else
    pwaic = sum(var(lnl, [], 2));
end
WAIC  = -2 * (lppd - pwaic);