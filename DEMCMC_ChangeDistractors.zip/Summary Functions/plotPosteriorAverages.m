%% Organise data mean accuracy, d-prime, and mean RT functions
data.acc = zeros(size(data.resp, 1), 1);
data.acc(data.changes == 0 & data.resp == 1 | data.changes > 0 & data.resp == 2) = 1;

data.icMat = data.itemConditions(data.item,:);

pCorrect = [aggregate([data.icMat(:,3:-1:2), data.acc], [1 2] , 3),...
            aggregate([data.icMat(:,3:-1:2), data.acc], [1 2] , 3, @std, 1)./sqrt(aggregate([data.icMat(:,3:-1:2), data.acc], [1 2] , 3, @count, 1))];
pCorrect = sortrows([pCorrect; 2 0 nan nan], [1 2]);

rt = [aggregate([data.icMat(:,3:-1:2), data.rt], [1 2] , 3, @nanmean),...
      aggregate([data.icMat(:,3:-1:2), data.rt], [1 2] , 3, @nanstd, 1)./sqrt(aggregate([data.icMat(:,3:-1:2), data.rt], [1 2] , 3, @count, 1))];
rt = sortrows([rt; 2 0 nan nan], [1 2]);

% Organize for plotting
macc = reshape(pCorrect(:,3), 4, 3);
sacc = reshape(pCorrect(:,4), 4, 3);
mrt  = reshape(rt(:,3), 4, 3);
srt  = reshape(rt(:,4), 4, 3);

% Find d-prime using the differencing model
hr = macc(:,2:3);
fa = (1 - macc(:,[1 1]))./2;
zH = norminv(hr);
zF = norminv(fa);
c = -norminv(fa);
d = zH - zF;

dlo = norminv(macc(:,2:3) - sacc(:,2:3)) - norminv((1 - (macc(:,[1 1]) - sacc(:,[1 1])))./2);
dhi = norminv(macc(:,2:3) + sacc(:,2:3)) - norminv((1 - (macc(:,[1 1]) + sacc(:,[1 1])))./2);

%% Organise predictions 

avgrtcell = arrayfun(@(x)aggregate([sims{x}.item, sims{x}.rt], 1, 2, @mean, 1), 1:n.postsamples, 'UniformOutput', false);
avgrt = cell2mat(avgrtcell);

for i = 1:n.postsamples
sims{i}.acc = zeros(size(sims{i}.resp));
sims{i}.acc(sims{i}.resp == 2 & ismember(sims{i}.item, data.itemConditions(data.itemConditions(:,3) > 0, 1)) |...
    sims{i}.resp == 1 & ismember(sims{i}.item, data.itemConditions(data.itemConditions(:,3) == 0, 1))) = 1;
end
avgacccell = arrayfun(@(x)aggregate([sims{x}.item, sims{x}.acc], 1, 2, @mean, 1), 1:n.postsamples, 'UniformOutput', false);
avgacc = cell2mat(avgacccell);

% Summarize for plotting
simcorrect = aggregate([data.itemConditions(:,3:-1:2) avgacc], [1 2], [3:n.postsamples+2]);
simcorrect = sortrows([simcorrect; 2 0 nan(1, n.postsamples)], [1 2]);

simrt = aggregate([data.itemConditions(:,3:-1:2) avgrt], [1 2], [3:n.postsamples+2]);
simrt= sortrows([simrt; 2 0 nan(1, n.postsamples)], [1 2]);


% Find d-prime using the differencing model
simhr = simcorrect(simcorrect(:,1) > 0, 3:end);
simfa = (1-repmat(simcorrect(simcorrect(:,1) == 0, 3:end), 2, 1))./2;
simzH = norminv(simhr);
simzF = norminv(simfa);
simc = -norminv(simfa);
simd = simzH - simzF;   

simd = [simcorrect(simcorrect(:,1) ~= 0, 1:2), simd];

%% Plot accuracy
figure_avg = figure('WindowStyle', 'docked');
set(figure_avg, 'Color', 'w')
subplot(1,3,1)

% No change
temp = simcorrect(simcorrect(:,1) == 0, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp',...
        'facecolor', [1 0 0], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bounds', [0 1]);%, 'bw', bandwidth);
hold on

% 1 change
temp = simcorrect(simcorrect(:,1) == 1, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp',...
        'facecolor', [0 1 0], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bounds', [0 1]);%, 'bw', bandwidth);

% 2 change
temp = simcorrect(simcorrect(:,1) == 2, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp(2:4,:)', 'x',[2 3 4], ...
        'facecolor', [0 0 1], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bounds', [0 1]);%, 'bw', bandwidth);

%% Plot rt
figure(figure_avg)
subplot(1,3,3)
% No change
temp = simrt(simrt(:,1) == 0, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp',...
        'facecolor', [1 0 0], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bw', bandwidth);
hold on

% 1 change
temp = simrt(simrt(:,1) == 1, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp',...
        'facecolor', [0 1 0], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bw', bandwidth);

% 2 change
temp = simrt(simrt(:,1) == 2, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp(2:4,:)', 'x',[2 3 4], ...
        'facecolor', [0 0 1], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bw', bandwidth);

%% Plot d-prime
figure(figure_avg)
subplot(1,3,2)

% 1 change
temp = simd(simd(:,1) == 1, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp',...
        'facecolor', [0 1 0], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bw', bandwidth);
hold on

% 2 change
temp = simd(simd(:,1) == 2, 3:end); 
bandwidth = max(getbandwidth(temp(:)), .01);

[h, L, MX, MED, bw] = violin(temp(2:4,:)', 'x',[2 3 4], ...
        'facecolor', [0 0 1], 'edgecolor', 'k', 'facealpha', .5, 'mc', '', 'medc', '', 'bw', bandwidth);



%% Plot average data
lineStyles = {'-or', '--^g', ':sb'};
colors = {'r', 'g', 'b'};
elineStyles = {'-', '--', ':'};
for idx = 1:3
    subplot(1,3,1)
    eb_han = errorbar(1:4, macc(:,idx), sacc(:,idx), sacc(:,idx));
    set(eb_han, 'LineStyle', elineStyles{idx}, 'LineWidth', 2, 'MarkerSize', 10, 'Color', colors{idx})
    hold on
    l_han(idx) = plot(1:4, macc(:,idx), lineStyles{idx}, 'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', colors{idx});
    set(gca, 'XLim', [.5 4.5], 'XTick', 1:4, 'YLim', [0 1], 'FontSize', 14)
    xlabel('Set Size')
    ylabel('Accuracy')
    
    subplot(1,3,3)
    ebrt_han = errorbar(1:4, mrt(:,idx), srt(:,idx), srt(:,idx));
    set(ebrt_han, 'LineStyle', elineStyles{idx}, 'LineWidth', 2, 'MarkerSize', 10, 'Color', colors{idx})
    hold on
    plot(1:4, mrt(:,idx), lineStyles{idx}, 'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', colors{idx})
    set(gca, 'XLim', [.5 4.5], 'XTick', 1:4, 'YLim', [0 2], 'FontSize', 14)
    xlabel('Set Size')
    ylabel('Mean RT (msec)')
    
    % Plot d-prime
    if idx <= 2
        subplot(1,3,2)
        ebd_han = errorbar(1:4, d(:,idx), d(:,idx)-dlo(:,idx), dhi(:,idx)-d(:,idx));
        set(ebd_han, 'LineStyle', elineStyles{idx}, 'LineWidth', 2, 'MarkerSize', 10, 'Color', colors{idx+1})
        hold on
        plot(1:4, d(:,idx), lineStyles{idx+1}, 'LineWidth', 2, 'MarkerSize', 10, 'MarkerFaceColor', colors{idx+1})
        
        set(gca, 'XLim', [.5 4.5], 'XTick', 1:4, 'YLim', [0 4], 'FontSize', 14)
        xlabel('Set Size')
        ylabel('d-prime')
    end
end
legend(l_han([1 3 2]), 'No Change', '2 Change', '1 Change')