clear all
clc
close all

% models = {'coactivemx', 'coactivemn', 'parallelst', 'parallelex', 'parallelrb', 'serialst', 'serialex', 'serialrb', 'max  '}; 
model = 'parallelst';
subjects  = [2, 3, 5, 6, 4]; 
sublabels = {'O1', 'O2', 'O3', 'O4', 'O5'};

parameter_names = {'db_{x}', 'db_{y}', '\sigma_{x}', '\sigma_{y}', 'A', 'b_{Change}', 'b_{No Change}', 's', 't_{0}'};
xlimits = {[0,1], [0,1], [0, 1.5], [0, 1.5], [0, .5], [0, 1], [0, 1], [0, .5], [0, .3]};

for si = 1:numel(subjects)
   fn = sprintf('ChangeDetection_s%d_%s_t.mat', subjects(si), model);
   
   % Load the fit file 
   load(fullfile(pwd, 'Fits', fn))
   
   % Get field names for each parms
   names = fieldnames(theta);
   for j = 1:numel(names)
        temp = theta.(names{j})(:,n.burnin:end);
        temp = datasample(temp(:), 2000);
        postparms.(names{j})(:,si) = temp;
   end
end
postparms.bMa1 = postparms.bMa1 + postparms.A;
postparms.bMa2 = postparms.bMa2 + postparms.A;

%% Now plot results
figure('WindowStyle', 'docked')
[nr, nc] = nsubplots(numel(names));
sploc = [1 2 3 4 5 6 7 9 10];
colors = {[1 0 0], [0 1 0], [0 0 1], [1 1 0], [1 0 1], [0 1 1]};
for j = 1:numel(names)
    subplot(3,4,sploc(j))

    minx = min(postparms.(names{j})(:)) - std(postparms.(names{j})(:)); 
    maxx = max(postparms.(names{j})(:)) + std(postparms.(names{j})(:)); 
    
    xi = linspace(minx, maxx, 200);
    
    for si = 1:numel(subjects)
        f1(si,:) = ksdensity(postparms.(names{j})(:,si), xi);
    
        mf1(si) = fill([xi, fliplr(xi)], [f1(si,:), zeros(1,size(f1(si,:),2))], colors{si}, 'FaceAlpha', .5); hold on
    end
    xlabel(parameter_names{j})
    ylabel('Posterior Density')
    if j == 1; legend(mf1, sublabels,'Location','NorthWest'); end
    set(gca, 'XLim', xlimits{j});
end