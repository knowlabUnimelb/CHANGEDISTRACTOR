%% Posterior predictive checks
% Steps: sample sets of parameters from the posterior
% Will need to generate predictive RT distributions, and mean accuracy, RT plots

close all % close all open figures

%% Sample posterior parameters

% Drop burnin and reshape
n.burnin = n.mc - 750; % reestimate burnin
n.postsamples = 200;
n.nsimtrials = 10000; % Number of simulated trials

% Reshape
parmsStruct = structfun(@(x) reshape(x(:,n.burnin:end), numel(theta.(names{1})(:,n.burnin:end)), 1), theta, 'UniformOutput', false);
parmsMat = cell2mat(struct2cell(parmsStruct)');
parms = datasample(parmsMat, n.postsamples, 1);

% Find and store best parms
[fit, ifit] = max(weight, [], 'all');
[idxfit, jdxfit] = ind2sub(size(weight), ifit);
bestparms = structfun(@(x)(x(idxfit, jdxfit)), theta, 'UniformOutput', false);

samples_fn = [strtok(fn, '.'), '_samples.mat'];

%% Sample predictions for each item condition
% parmstr = strjoin(names, ',');

if exist(samples_fn, 'file') ~= 2
    for i = 1:n.postsamples
        % Sample from random chains
        parmcells = num2cell(parms(i,:));
        labelledParmStr = cell(1, numel(parmcells));
        for pidx = 1:numel(parmcells)
            labelledParmStr{pidx} = sprintf('''%s'', %d', names{pidx}, parmcells{pidx});
        end

        % Generate test data
        parmstr = strjoin(labelledParmStr, ',');        
        eval(sprintf('[sims{i}, simparms{i}] = generateTestData(model, n.nsimtrials, data, %s);', parmstr))
    end

    % Sample MLE data
    bestparmcells = struct2cell(bestparms)';
    bestlabelledParmStr = cell(1, numel(bestparmcells));
    for pidx = 1:numel(bestparmcells)
        bestlabelledParmStr{pidx} = sprintf('''%s'', %d', names{pidx}, bestparmcells{pidx});
    end
    bestparmstr = strjoin(bestlabelledParmStr, ',');
    eval(sprintf('[bestsims, bestsimparms] = generateTestData(model, n.nsimtrials, data, %s);', bestparmstr))

else
    fprintf('Loading data\n')
    load(samples_fn, 'sims', 'simparms')
    fprintf('Data loaded\n')
end

%% Simulate data using average parms
avgparmcells = num2cell(mean(parms));
        
% Generate test data
labelledParmStr = cell(1, numel(avgparmcells));
for pidx = 1:numel(avgparmcells)
    labelledParmStr{pidx} = sprintf('''%s'', %d', names{pidx}, avgparmcells{pidx});
end

% Generate test data
parmstr = strjoin(labelledParmStr, ',');        
eval(sprintf('[avgsims, avgsimparms] = generateTestData(model, n.nsimtrials, data, %s);', parmstr))

%% Density fits for each item condition
figure1 = figure('WindowStyle', 'docked'); % Plot density fits of each item
figure(figure1)

n.items = size(data.itemConditions, 1); % N item conditions
nr = 4; nc = 7; % Subplot rows and columsn
sploc = [1:3, 8:28]; % plotting locations

% Subplot titles
titles = {'Set Size 1: 0 Change', 'Set Size 1: L Change', 'Set Size 1: H Change',...
          'Set Size 2: 0 Change', 'Set Size 2: L Change', 'Set Size 2: H Change',...
          'Set Size 2: LL Change', 'Set Size 2: LH Change', 'Set Size 2: HL Change', 'Set Size 2: HH Change',...
          'Set Size 3: 0 Change', 'Set Size 3: L Change', 'Set Size 3: H Change',...
          'Set Size 3: LL Change', 'Set Size 3: LH Change', 'Set Size 3: HL Change', 'Set Size 3: HH Change',...   
          'Set Size 4: 0 Change', 'Set Size 4: L Change', 'Set Size 4: H Change',...
          'Set Size 4: LL Change', 'Set Size 4: LH Change', 'Set Size 4: HL Change', 'Set Size 4: HH Change'};

cresp = [1 2 2 1 2 2 2 2 2 2 1 2 2 2 2 2 2 1 2 2 2 2 2 2];

% Loop through item conditions
plotsamples = datasample(1:n.postsamples, 20);
cnt = 1; % start counter
for k = 1:n.items
    % Density plot
    if k == 1; densfig = figure('WindowStyle', 'docked'); cdffig = figure('WindowStyle', 'docked'); end
    figure(densfig);
    subplot(nr,nc,sploc(k)); % subplot

    % On first iteration plot data
    tmp.datart = data.rt(data.item == k);
    tmp.datart(data.resp(data.item == k) == 2) = -1 * tmp.datart(data.resp(data.item == k) == 2); % Make errors negative
    tmp.datart(abs(tmp.datart)>3)=nan; % Just remove some outliers for plotting purposes.
    
    t = linspace(-4, 4, 50);
    [c, e] = hist(tmp.datart, t);
    b = bar(e, c./trapz(e,c), 'hist'); % * mean(tmp.dataacc == 1), 'hist');
    set(b, 'FaceColor', [0 .95 .95])
    hold on
    set(gca,'XLim', [-2 2]);
        
    for idx = plotsamples
        % Plot line for simulation density
        tmp.simrt = sims{idx}.rt(sims{idx}.item == k);
        tmp.simrt(sims{idx}.resp(sims{idx}.item == k) == 2) = -1 * tmp.simrt(sims{idx}.resp(sims{idx}.item == k) == 2);
        tmp.simrt(abs(tmp.simrt) > 3)=nan; % Just remove some outliers for plotting purposes.
        
        hbw = getbandwidth(tmp.simrt(~isnan(tmp.simrt)));
        [dens, xi] = ksdensity(tmp.simrt(~isnan(tmp.simrt)), 'kernel', 'epanechnikov', 'bandwidth', .01); % This uses KDE
        plot(xi, dens, '-r', 'LineWidth', 1)
        xlabel('RT (secs)')
        ylabel('Density')
        title(titles{k});
        hold on
    end
    
    % Plot predictions using average parms
    tmp.simrt = avgsims.rt(avgsims.item == k);
    tmp.simrt(avgsims.resp(avgsims.item == k) == 2) =...
        -1 * tmp.simrt(avgsims.resp(avgsims.item == k) == 2);
    tmp.simrt(abs(tmp.simrt)>3)=nan; % Just remove some outliers for plotting purposes.
    
    hbw = getbandwidth(tmp.simrt(~isnan(tmp.simrt)));
    [dens, xi] = ksdensity(tmp.simrt(~isnan(tmp.simrt)), 'kernel', 'epanechnikov', 'bandwidth', .01); % This uses KDE
    plot(xi, dens, '-b', 'LineWidth', 2)
    xlabel('RT (secs)')
    ylabel('Density')
    title(titles{k});
    hold on 

    % CDF plot
    figure(cdffig);
    subplot(nr,nc,sploc(k)); % subplot    
    tmp.datart = data.rt(data.item == k);
    tmp.datart(abs(tmp.datart)>3)=nan; % Just remove some outliers for plotting purposes.

    crt = tmp.datart(data.resp(data.item == k) == cresp(k)); % correct rts
    pc = sum(data.resp(data.item == k) == cresp(k))./numel(data.resp(data.item == k));
    ert = tmp.datart(data.resp(data.item == k) ~= cresp(k)); % error rts
    pe = sum(data.resp(data.item == k) ~= cresp(k))./numel(data.resp(data.item == k));

    t = linspace(0, 2, 50);
    [c, e] = hist(crt, t);
    plot(t, pc * cumsum(c./sum(c)), '-g'); hold on

    [c, e] = hist(ert, t);
    plot(t, pe * cumsum(c./sum(c)), '-r'); 
    set(gca,'XLim', [0 2], 'YLim', [0 1]);

    % Plot cdf predictions using best parms
    tmp.simrt = bestsims.rt(bestsims.item == k);
    tmp.simresp = bestsims.resp(bestsims.item == k);
    tmp.simrt(abs(tmp.simrt)>3)=nan; % Just remove some outliers for plotting purposes.
    
    simcrt = tmp.simrt(tmp.simresp == cresp(k)); % correct rts
    simpc = sum(tmp.simresp == cresp(k))./numel(tmp.simresp);
    simert = tmp.simrt(tmp.simresp ~= cresp(k)); % correct rts
    simpe = sum(tmp.simresp ~= cresp(k))./numel(tmp.simresp);

    t = linspace(0, 2, 50);
    [c, e] = hist(simcrt, t);
    plot(t, simpc * cumsum(c./sum(c)), '--g'); hold on

    [c, e] = hist(simert, t);
    plot(t, simpe * cumsum(c./sum(c)), '--r'); 
    set(gca,'XLim', [0 2], 'YLim', [0 1]);

    xlabel('RT (secs)')
    ylabel('cdf')
    title(titles{k});

end

%% Plot posterior SIC predictions
plotSurvivors = false;
% plotPosteriorSICs;

%% Plot posterior averages
% plotPosteriorAverages
