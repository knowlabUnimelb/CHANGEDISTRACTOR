%% Plot posterior SIC predictions
figure_sic = figure('WindowStyle', 'docked'); % SICs
figure_sicContour = figure('WindowStyle', 'docked'); % Plot density fits of each item
if plotSurvivors
    figure_Sss2 = figure('WindowStyle', 'docked'); % Survivors set size 2
    figure_Sss3 = figure('WindowStyle', 'docked'); % Survivors set size 3
    figure_Sss4 = figure('WindowStyle', 'docked'); % Survivors set size 4
end

% There are three SIC's (set size 2, set size 3, set size 4)
sicItemNames = {'s2_LL', 's2_LH', 's2_HL', 's2_HH',...
    's3_LL', 's3_LH', 's3_HL', 's3_HH',...
    's4_LL', 's4_LH', 's4_HL', 's4_HH'};
itemConditionIdx = [7:10, 14:17, 21:24];

plotsamples = datasample(1:n.postsamples, 20);
for idx = 1:numel(plotsamples)
    ii = plotsamples(idx);
    for j = 1:numel(sicItemNames)
        eval(sprintf('%s = sims{%d}.rt(sims{%d}.item == itemConditionIdx(%d)) * 1000;',...
            sicItemNames{j}, ii, ii, j)); % Get simulated RTs

        % Set up simulated accuracy variable
        eval(sprintf('%sacc = ones(numel(%s), 1);', sicItemNames{j}, sicItemNames{j}));
        eval(sprintf('%sacc(sims{%d}.resp(sims{%d}.item == itemConditionIdx(%d)) == 2) = 0;',...
            sicItemNames{j}, ii, ii, j));
    end

    % Calculate SICs for each set size
    [s2_psic(:,idx), s2_cdf, s2_S, s2_t, s2_sichi, s2_siclo] =...
        computeSIC(s2_LL, s2_LH, s2_HL, s2_HH,...
        s2_LLacc, s2_LHacc, s2_HLacc, s2_HHacc,...
        5, 3000, 1000, 'empirical');

    [s3_psic(:,idx), s3_cdf, s3_S, s3_t, s3_sichi, s3_siclo] =...
        computeSIC(s3_LL, s3_LH, s3_HL, s3_HH,...
        s3_LLacc, s3_LHacc, s3_HLacc, s3_HHacc,...
        5, 3000, 1000, 'empirical');

    [s4_psic(:,idx), s4_cdf, s4_S, s4_t, s4_sichi, s4_siclo] =...
        computeSIC(s4_LL, s4_LH, s4_HL, s4_HH,...
        s4_LLacc, s4_LHacc, s4_HLacc, s4_HHacc,...
        5, 3000, 1000, 'empirical');

    %% Plot SICs for each set size
    figure(figure_sic)
    subplot(1,3,1)
    s2_hsic = plot(s2_t, s2_psic(:,idx));
    hold on
    set(s2_hsic, 'Color', [.75 .75 .75], 'LineStyle', '-' , 'LineWidth', 1)
    if idx == 1; title('Set Size 2'); end

    subplot(1,3,2)
    s3_hsic = plot(s3_t, s3_psic(:,idx));
    hold on
    set(s3_hsic, 'Color', [.75 .75 .75], 'LineStyle', '-' , 'LineWidth', 1)
    if idx == 1; title('Set Size 3'); end

    subplot(1,3,3)
    s4_hsic = plot(s4_t, s4_psic(:,idx));
    hold on
    set(s4_hsic, 'Color', [.75 .75 .75], 'LineStyle', '-' , 'LineWidth', 1)
    if idx == 1; title('Set Size 4'); end

    if plotSurvivors
        %% Plot survivors for each set size
        % Set size 2
        figure(figure_Sss2)
        subplot(4,5,idx)
        plot(s2_t, s2_S); hold on
        set(gca,'XLim', [0 3000])
        if ismember(idx, [1 6 11 16])
            ylabel('S(t)')
        elseif ismember(idx, 16:20)
            xlabel('t')
            if idx == 20
                legend({'HH', 'HL', 'LH', 'LL'})
                supertitle('Set Size 2')
            end
        end

        % Set size 3
        figure(figure_Sss3)
        subplot(4,5,idx)
        plot(s3_t, s3_S); hold on
        set(gca,'XLim', [0 3000])
        if ismember(idx, [1 6 11 16])
            ylabel('S(t)')
        elseif ismember(idx, 16:20)
            xlabel('t')
            if idx == 20
                legend({'HH', 'HL', 'LH', 'LL'})
                supertitle('Set Size 3')
            end
        end

        % Set size 4
        figure(figure_Sss4)
        subplot(4,5,idx)
        plot(s4_t, s4_S); hold on
        set(gca,'XLim', [0 3000])
        if ismember(idx, [1 6 11 16])
            ylabel('S(t)')
        elseif ismember(idx, 16:20)
            xlabel('t')
            if idx == 20
                legend({'HH', 'HL', 'LH', 'LL'})
                supertitle('Set Size 4')
            end
        end
    end
end

% Plot data sic
for j = 1:numel(sicItemNames)
    eval(sprintf('d%s = data.rt(data.item==itemConditionIdx(%d))*1000;', sicItemNames{j}, j));
    eval(sprintf('d%sacc = data.resp(data.item==itemConditionIdx(%d)) == 2;', sicItemNames{j}, j));
end

[ds2_sic, ds2_cdf, ds2_S, ds2_t, ds2_sichi, ds2_siclo] =...
    computeSIC(ds2_LL, ds2_LH, ds2_HL, ds2_HH,...
    ds2_LLacc, ds2_LHacc, ds2_HLacc, ds2_HHacc,...
    5, 3000, 1000, 'empirical');

[ds3_sic, ds3_cdf, ds3_S, ds3_t, ds3_sichi, ds3_siclo] =...
    computeSIC(ds3_LL, ds3_LH, ds3_HL, ds3_HH,...
    ds3_LLacc, ds3_LHacc, ds3_HLacc, ds3_HHacc,...
    5, 3000, 1000, 'empirical');

[ds4_sic, ds4_cdf, ds4_S, ds4_t, ds4_sichi, ds4_siclo] =...
    computeSIC(ds4_LL, ds4_LH, ds4_HL, ds4_HH,...
    ds4_LLacc, ds4_LHacc, ds4_HLacc, ds4_HHacc,...
    5, 3000, 1000, 'empirical');

figure(figure_sic)
subplot(1,3,1)
plot(ds2_t, ds2_sic, '-k');
hold on
xlabel('t', 'FontSize', 14)
ylabel('SIC(t)', 'FontSize', 14)
axis tight
l = line([5 3000], [0 0]); set(l, 'Color', 'k')
set(gca,'FontSize', 14)

subplot(1,3,2)
plot(ds3_t, ds3_sic, '-k');
hold on
xlabel('t', 'FontSize', 14)
ylabel('SIC(t)', 'FontSize', 14)
axis tight
l = line([5 3000], [0 0]); set(l, 'Color', 'k')
set(gca,'FontSize', 14)

subplot(1,3,3)
plot(ds4_t, ds4_sic, '-k');
hold on
xlabel('t', 'FontSize', 14)
ylabel('SIC(t)', 'FontSize', 14)
axis tight
l = line([5 3000], [0 0]); set(l, 'Color', 'k')
set(gca,'FontSize', 14)

%% Plot SIC as a filled contour
figure(figure_sicContour)

subplot(1,3,1)
s2_mPosteriorSic = mean(s2_psic, 2);
s2_sPosteriorSic = std(s2_psic, [], 2);
s2_x = [s2_t'; flipud(s2_t')];
s2_y = [s2_mPosteriorSic + (2.58 * s2_sPosteriorSic); flipud(s2_mPosteriorSic - (1.96 * s2_sPosteriorSic))];
fillcol=[.6 .6 .8];
fill(s2_x,s2_y, fillcol, 'EdgeColor', fillcol)
hold on
ds2_smoothSic = conv(ds2_sic, ones(1,1)/1, 'same');
plot(ds2_t, ds2_smoothSic, '-', 'Color', 'b', 'LineWidth', 2);
xlabel('t', 'FontSize', 14)
ylabel('SIC(t)', 'FontSize', 14)
axis tight
l = line([5 3000], [0 0]); set(l, 'Color', 'k')
set(gca,'FontSize', 14)

subplot(1,3,2)
s3_mPosteriorSic = mean(s3_psic, 2);
s3_sPosteriorSic = std(s3_psic, [], 2);
s3_x = [s3_t'; flipud(s3_t')];
s3_y = [s3_mPosteriorSic + (2.58 * s3_sPosteriorSic); flipud(s3_mPosteriorSic - (1.96 * s3_sPosteriorSic))];
fillcol=[.6 .6 .8];
fill(s3_x,s3_y, fillcol, 'EdgeColor', fillcol)
hold on
ds3_smoothSic = conv(ds3_sic, ones(1,1)/1, 'same');
plot(ds3_t, ds3_smoothSic, '-', 'Color', 'b', 'LineWidth', 2);
xlabel('t', 'FontSize', 14)
ylabel('SIC(t)', 'FontSize', 14)
axis tight
l = line([5 3000], [0 0]); set(l, 'Color', 'k')
set(gca,'FontSize', 14)

subplot(1,3,3)
s4_mPosteriorSic = mean(s4_psic, 2);
s4_sPosteriorSic = std(s4_psic, [], 2);
s4_x = [s4_t'; flipud(s4_t')];
s4_y = [s4_mPosteriorSic + (2.58 * s4_sPosteriorSic); flipud(s4_mPosteriorSic - (1.96 * s4_sPosteriorSic))];
fillcol=[.6 .6 .8];
fill(s4_x,s4_y, fillcol, 'EdgeColor', fillcol)
hold on
ds4_smoothSic = conv(ds4_sic, ones(1,1)/1, 'same');
plot(ds4_t, ds4_smoothSic, '-', 'Color', 'b', 'LineWidth', 2);
xlabel('t', 'FontSize', 14)
ylabel('SIC(t)', 'FontSize', 14)
axis tight
l = line([5 3000], [0 0]); set(l, 'Color', 'k')
set(gca,'FontSize', 14)