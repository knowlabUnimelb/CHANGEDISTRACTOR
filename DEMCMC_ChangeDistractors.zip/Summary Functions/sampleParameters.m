function varargout  = sampleParameters(theta, n, i)

names = fieldnames(theta);

for idx = 1:numel(names)
   eval(sprintf('%s = theta.(names{idx})(datasample(1:n.chains, 1), i);', names{idx}));
   eval(sprintf('varargout{idx} = %s;', names{idx}));
end