clear all
clc

models = {'samplesizest', 'samplesize_boundaryst', 'samplesize_ndtst',...
    'coactivemn', 'coactive_boundarymn',...
    'parallelst', 'parallel_boundaryst'}; 
% ors  = {'O1', 'O2', 'O3', 'O4', 'O5'};
ors = {'1', '2', '3', '4'};
%ands = [901, 902, 903, 904, 905];
subjects = ors;

for sidx = 1:numel(subjects)
    disp(sidx)
    subject = subjects{sidx};
    fitfolder = fullfile(pwd, 'Fits');
    
    for i = 1:numel(models)
        load(fullfile(fitfolder, sprintf('ChangeDistractor_s%s_%s_t.mat', subject, models{i})), 'model', 'data', 'theta', 'logtheta', 'weight', 'n')
        n.burnin = n.mc - 750;
        idx = n.burnin:n.mc;
        
        [dic1(sidx,i), dic1_fit(sidx,i), dic1_penalty(sidx,i)] =...
            computeDIC(model, data, logtheta, weight(:,idx), 1, idx);
        [dic2(sidx,i), dic2_fit(sidx,i), dic2_penalty(sidx,i)] =...
            computeDIC(model, data, logtheta, weight(:,idx), 2, idx);

        names = fieldnames(theta);
    end
end
