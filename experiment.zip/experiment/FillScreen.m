function FillScreen(screenparms)
Screen('FillRect', screenparms.window, screenparms.color); 