% Lauren Fong 2019 Honours Project %Hello
% Change de66tection with distractors
%
% Set sizes 1 - 4
%  - If set size one, probe can be same, hard, or easy
%  - If set size 2-4, probe can be same, one diff: hard, easy, two diff: HH, HL, LH, LL
%
% Set size 1: 240 same, 120 L, 120 H = 480 trials
% Set size 2-4: 720 same trials
%               120 one diff: hard, 120 one diff: easy = 240 trials
%               120 two diff: HH, 120 two diff: HL = 240 
%               120 two diff: LH, 120 two diff: LL = 240 
%                                                        = 720 trials
% = 3 * (720 + 720) = 4320 + 480 =  4800
% 12 sessions of 400 trials 

%%
clear all
clc
WaitSecs(1e-7); % Hack to load WaitSecs
warning('off', 'MATLAB:mex:deprecatedExtension')

Screen('Preference', 'SkipSyncTests', 1)

% If debug == true, do experiment with reduced number of trials (use keyboard instead of RT box)
debug = true;
RTBox('fake', debug)

%% Environment Variables
xup = -50; xleft = -18; % center of screen offsets for showtext
bgcolor = [128 128 128]; % User specified background color
feedback = {'...Wrong...', '...Correct...'};
textsize = 60;
timeout = 5;
green = [0 238 0];
red   = [238 0 0];

feedbackWhenWrong = 1;
feedbackWhenRight = 1;
feedbackWhenSlow = 1;
feedbackAfterBlock = 1;

%% Experimental Variables
seed = 31377;

fixationDuration  = .5;  % Fixation cross presentation length
targetPresTime = 1;
noiseLoopTime  = .25; 
noiseDelayTime = .1;
noisePresTime     = 1;
postNoiseTime     = 1;
fbkDuration       = 1;     % Feedback presentation length
citi = .5;

dotWidth = 35; %

%% Trial numbers
nBlocks = 16;                           % Number of blocks = 16
nTrialsPerBlock = 25;                   % Number of trials per block = 25
nExpTrials  = nBlocks*nTrialsPerBlock; % Number of experimental trials

%% Open Experiment Window
% Parameters - make sure that these are correct
screenWidth = 40;           % cm
viewingDistance = 60;       % cm

% Present subject information screen until correct information is entered
subject     = input('Enter Subject Number [101-110]:');
session     = input('Enter Session Number [1-12]:');
rng(seed + session * subject * 2)
outputfile = sprintf('2019_changeDistractor_%03d_%02d.dat', subject, session);

screenparms = prepexp([], bgcolor); % Open onscreen window

% % Determine positions of the disks
cx = round(screenparms.width/2);
cy = round(screenparms.height/2);
screenWidth = 40;           % cm
viewingDistance = 60;       % cm
degPerPixel = 360/pi*atan(screenWidth/(2*viewingDistance))/screenparms.width;

xx = cx-6/degPerPixel; yy = cy;
targetLocations(1,:) = [cx-6/degPerPixel, cy];
targetLocations(2,:) = [cx cy-6/degPerPixel];
targetLocations(3,:) = [cx+6/degPerPixel cy];
targetLocations(4,:) = [cx cy+6/degPerPixel];
targetLocations = round(targetLocations');
% targetLocations(1,:) = targetLocations(1,:) - screenparms.rect(3)/2;
% targetLocations(2,:) = targetLocations(2,:) - screenparms.rect(4)/2;


fixationPosition = [cx cy cx cy; cx cy cx cy]' + 1/degPerPixel*[ -0.05 -0.25 0.05 0.25; -0.25 -0.05 0.25 0.05]';

%% Stimulus variables
targetValues = [32, 64, 96, 160, 192, 224];
offset = 16; % 19-03-28: value of 30 was too large 
probeValues = {{[32], [32+offset], [32 + offset * 2]},... % same, low, high
               {[64], [64 + [-offset, offset]], [64 + [-2*offset, 2*offset]]},...
               {[96], [96-offset], [96 - offset * 2]},...
               {[160], [160+offset], [160 + offset * 2]},...
               {[192], [192 + [-offset, offset]], [192 + [-2*offset, 2*offset]]},...
               {[224], [224-offset], [224 - offset * 2]}};

           
           
           
%% Distribution of trials per session         
% set size probabilities [1/10, 3/10, 3/10, 3/10] = [40, 120, 120, 120]           
% if set size 1: [1/2 same, 1/4 L, 1/4 H] = [20, 10, 10]
% if set size 2: [1/2 same, 1/12 L, 1/12 H, 1/12 HH, 1/12 HL, 1/12 LH, 1/12 LL] = [60, 10, 10, 10, 10, 10, 10]
% if set size 3: [1/2 same, 1/12 L, 1/12 H, 1/12 HH, 1/12 HL, 1/12 LH, 1/12 LL] = [60, 10, 10, 10, 10, 10, 10]
% if set size 4: [1/2 same, 1/12 L, 1/12 H, 1/12 HH, 1/12 HL, 1/12 LH, 1/12 LL] = [60, 10, 10, 10, 10, 10, 10]

% Trial matrix (set size, trial type)
trialMatrix = [[ones(40, 1) * 1; ones(120, 1) * 2; ones(120, 1) * 3; ones(120, 1) * 4],... % Set size
               [ones(20, 1) * 0; ones(10, 1) * 1; ones(10, 1) * 2;...
               ones(60, 1) * 0; ones(10, 1) * 1; ones(10, 1) * 2; ones(10, 1) * 1; ones(10, 1) * 1;  ones(10, 1) * 2; ones(10, 1) * 2;...
               ones(60, 1) * 0; ones(10, 1) * 1; ones(10, 1) * 2; ones(10, 1) * 1; ones(10, 1) * 1;  ones(10, 1) * 2; ones(10, 1) * 2;...
               ones(60, 1) * 0; ones(10, 1) * 1; ones(10, 1) * 2; ones(10, 1) * 1; ones(10, 1) * 1;  ones(10, 1) * 2; ones(10, 1) * 2],...
               [nan(40, 1);...
                nan(80, 1); ones(10, 1) * 1; ones(10, 1) * 2;  ones(10, 1) * 1; ones(10, 1) * 2;...
                nan(80, 1); ones(10, 1) * 1; ones(10, 1) * 2;  ones(10, 1) * 1; ones(10, 1) * 2;...
                nan(80, 1); ones(10, 1) * 1; ones(10, 1) * 2;  ones(10, 1) * 1; ones(10, 1) * 2]];
trialMatrix = trialMatrix(randperm(size(trialMatrix, 1)), :);                
           
anyDuplicates = @(x)(~all(diff(sort(x(x ~= 0))))); % Function to check for duplicates in an array

%% Mask stuff
% Get the size of the on screen window
[screenXpixels, screenYpixels] = Screen('WindowSize', screenparms.window);

% Get the centre coordinate of the window
[xCenter, yCenter] = RectCenter(screenparms.rect);

% Make a base Rect of 200 by 200 pixels
dim = 15;
baseRect = [0 0 dim dim];

% Make the coordinates for our grid of squares
[xPos, yPos] = meshgrid(-2:1:2, -2:1:2);

% Calculate the number of squares and reshape the matrices of coordinates
% into a vector
[s1, s2] = size(xPos);
numSquares = s1 * s2;
xPos = reshape(xPos, 1, numSquares);
yPos = reshape(yPos, 1, numSquares);

% Scale the grid spacing to the size of our squares and centre
xPosLeft = xPos .* dim + screenXpixels * targetLocations(1,1)/screenXpixels; % Adjust  screenXpixels * 0.25 for left and rigth position
yPosLeft = yPos .* dim + yCenter;

xPosTop = xPos .* dim + xCenter;
yPosTop = yPos .* dim + screenYpixels * targetLocations(2,2)/screenYpixels;

xPosRight = xPos .* dim + screenXpixels * targetLocations(1,3)/screenXpixels;
yPosRight = yPos .* dim + yCenter;

xPosBot = xPos .* dim + xCenter;
yPosBot = yPos .* dim + screenYpixels * targetLocations(2,4)/screenYpixels;

% Set the colors of each of our squares
bwColors = repmat(eye(2), 3, 3);
bwColors = bwColors(1:end-1, 1:end-1);
bwColors = reshape(bwColors, 1, numSquares);
bwColors = repmat(bwColors, 3, 1);

% Make our rectangle coordinates
allRectsLeft = nan(4, 3);
allRectsRight = nan(4, 3);
for i = 1:numSquares
    allRectsLeft(:, i) = CenterRectOnPointd(baseRect,...
        xPosLeft(i), yPosLeft(i));
    allRectsTop(:, i) = CenterRectOnPointd(baseRect,...
        xPosTop(i), yPosTop(i));    
    allRectsRight(:, i) = CenterRectOnPointd(baseRect,...
        xPosRight(i), yPosRight(i));
    allRectsBot(:, i) = CenterRectOnPointd(baseRect,...
        xPosBot(i), yPosBot(i));     
end

fullRectLeft  = round([allRectsLeft(1:2,1); allRectsLeft(3:4,end)])';
fullRectTop  = round([allRectsTop(1:2,1); allRectsTop(3:4,end)])';
fullRectRight = round([allRectsRight(1:2,1); allRectsRight(3:4,end)])';
fullRectBot  = round([allRectsBot(1:2,1); allRectsBot(3:4,end)])';

noiseRectLeft = nan(fullRectLeft(4) - fullRectLeft(2), fullRectLeft(3) - fullRectLeft(1));
noiseRectTop = nan(fullRectTop(4) - fullRectTop(2), fullRectTop(3) - fullRectTop(1));
noiseRectRight = nan(fullRectRight(4) - fullRectRight(2), fullRectRight(3) - fullRectRight(1));
noiseRectBot = nan(fullRectBot(4) - fullRectBot(2), fullRectBot(3) - fullRectBot(1));

%% PRESENT INSTRUCTIONS
instructionFolder = 'Instructions';
 trainingInstructions = {'Instructions (1).bmp', 'Instructions (2).bmp'};
 % RTBox('fake', 1)
showInstructions(screenparms, fullfile(pwd, instructionFolder, trainingInstructions{1}), 'RTBox')
showInstructions(screenparms, fullfile(pwd, instructionFolder, trainingInstructions{2}), 'RTBox')

breakImage = (fullfile(pwd, instructionFolder, 'Break.bmp'));
endImage = (fullfile(pwd, instructionFolder, 'Thanks.bmp'));

%%
showtext(screenparms, 20, 'Press any button to start experimental trials', 1, 0, 0);
Screen('Flip', screenparms.window); 
RTBox('clear'); % clear buffer and sync clocks before stimulus onset
while ~any(RTBox('ButtonDown')); WaitSecs(0.01); end % Wait for any button press
Screen('Flip', screenparms.window); 

%% Run Experiment
overallTrialCount = 1; 
overallcorrect = [];
for bblocks = 1:nBlocks
    %% Start of block loop
    output = [];
     
    blockStimlist = nan(nTrialsPerBlock,8); 
    response = nan(nTrialsPerBlock,1);
    rushtime = response;
    rt =  nan(nTrialsPerBlock,1);
    correctFlag =  nan(nTrialsPerBlock,1);
    blockTrialMatrix = nan(nTrialsPerBlock, size(trialMatrix, 2)); 
    priorityLevel = MaxPriority(screenparms.window,'WaitBlanking');
    
    % Start experiment
    trialcnt = 1;
    for i = 1:nTrialsPerBlock
        blockTrialMatrix(i,:) = trialMatrix(overallTrialCount,:);
        
        % Create noise masks for this trial
        randMaskLeft = rand([size(noiseRectLeft),2]);
        randMaskTop = rand([size(noiseRectTop),2]);
        randMaskRight = rand([size(noiseRectRight),2]);
        randMaskBot = rand([size(noiseRectBot),2]);
        
        randMaskLeft(randMaskLeft >= .5) = round((randMaskLeft(randMaskLeft >= .5)./10 + .9) * 255);
        randMaskLeft(randMaskLeft <  .5) = round((.1 - (randMaskLeft(randMaskLeft <  .5)./10)) * 255);
        randMaskTop(randMaskTop >= .5) = round((randMaskTop(randMaskTop >= .5)./10 + .9) * 255);
        randMaskTop(randMaskTop <  .5) = round((.1 - (randMaskTop(randMaskTop <  .5)./10)) * 255);
        randMaskRight(randMaskRight >= .5) = round((randMaskRight(randMaskRight >= .5)./10 + .9) * 255);
        randMaskRight(randMaskRight <  .5) = round((.1 - (randMaskRight(randMaskRight <  .5)./10)) * 255);
        randMaskBot(randMaskBot >= .5) = round((randMaskBot(randMaskBot >= .5)./10 + .9) * 255);
        randMaskBot(randMaskBot <  .5) = round((.1 - (randMaskBot(randMaskBot <  .5)./10)) * 255);
        
        ln{1} = Screen('MakeTexture', screenparms.window, randMaskLeft(:,:,1));
        ln{2} = Screen('MakeTexture', screenparms.window, randMaskLeft(:,:,2));
        tn{1} = Screen('MakeTexture', screenparms.window, randMaskTop(:,:,1));
        tn{2} = Screen('MakeTexture', screenparms.window, randMaskTop(:,:,2));        
        rn{1} = Screen('MakeTexture', screenparms.window, randMaskRight(:,:,1));
        rn{2} = Screen('MakeTexture', screenparms.window, randMaskRight(:,:,2));
        bn{1} = Screen('MakeTexture', screenparms.window, randMaskBot(:,:,1));
        bn{2} = Screen('MakeTexture', screenparms.window, randMaskBot(:,:,2));
        
        % Select stimuli for trial
        targets = datasample(targetValues, trialMatrix(overallTrialCount,1), 'Replace', false);
        if isnan(trialMatrix(overallTrialCount, end)) && trialMatrix(overallTrialCount,2) ~= 0  % One change
             % Select change location at random
             
             probes = nan(1,numel(targets));
             while any(isnan(probes)) || anyDuplicates(probes)
                 if anyDuplicates(probes)
                 probes = nan(1,numel(targets));
                 targets = datasample(targetValues, trialMatrix(overallTrialCount,1), 'Replace', false);
                 end
                 changeLocation = datasample(1:numel(targets), 1);
                 probeCells = probeValues{targets(changeLocation) == targetValues};
                 probeCellValues = probeCells{trialMatrix(overallTrialCount,2)+1};
                 probes(1, changeLocation) = datasample(probeCellValues, 1);
                 probes(isnan(probes)) = targets(isnan(probes));
             end
        elseif ~isnan(trialMatrix(overallTrialCount, end)) % Two changes
            probes = nan(1,numel(targets));
            while any(isnan(probes)) || anyDuplicates(probes)
                if anyDuplicates(probes)
                probes = nan(1,numel(targets));
                targets = datasample(targetValues, trialMatrix(overallTrialCount,1), 'Replace', false);
                end
                changeLocation = datasample(1:numel(targets), 2, 'Replace', false);
                for tidx = 1:numel(changeLocation)
                    probeCells = probeValues{targets(changeLocation(tidx)) == targetValues};
                    probeCellValues = probeCells{trialMatrix(overallTrialCount,tidx+1)+1};
                    probes(1, changeLocation(tidx)) = datasample(probeCellValues, 1);
                end
                probes(isnan(probes)) = targets(isnan(probes));
            end
        else % no changes
            probes = targets; 
        end
       
        sameTrial(i,1) = double(any(targets ~= probes)) + 1;
        
        % Select locations for stimuli
        locations = sort(datasample(1:4, trialMatrix(overallTrialCount, 1), 'Replace', false));
        
        %% Display stimuli
        Priority(priorityLevel);

        Screen('FillRect', screenparms.window, red, fixationPosition); %0*ones(3,2), 
        Screen('Flip', screenparms.window); 
        WaitSecs(fixationDuration);
        
         % Draw fixcross
        Screen('FillRect', screenparms.window, red, fixationPosition); %0*ones(3,2)

        % Draw targets
        for j = 1:numel(targets)
            blockStimlist(i,locations(j)) = targets(j);
            Screen('DrawDots', screenparms.window, targetLocations(:,locations(j)),...
                dotWidth, targets(j) * ones(1,3), [], 2);
        end
        Screen('Flip', screenparms.window);
        WaitSecs(targetPresTime);
        
        Screen('Flip', screenparms.window);
        % Present Noise mask
        for mi = 1:2
            Screen('DrawTexture', screenparms.window, ln{mi}, [], fullRectLeft)
            Screen('DrawTexture', screenparms.window, tn{mi}, [], fullRectTop)
            Screen('DrawTexture', screenparms.window, rn{mi}, [], fullRectRight)
            Screen('DrawTexture', screenparms.window, bn{mi}, [], fullRectBot)
            Screen('Flip', screenparms.window); 
            WaitSecs(noiseLoopTime);
        end
        
        FillScreen(screenparms)
        Screen('Flip', screenparms.window);
        WaitSecs(noiseDelayTime);
        
        Screen('FillRect', screenparms.window, red, fixationPosition);
        WaitSecs(noisePresTime);
        Screen('Flip', screenparms.window); 
        
        % Draw probes
         for j = 1:numel(targets)
            blockStimlist(i,locations(j)+4) = probes(j);
            Screen('DrawDots', screenparms.window, targetLocations(:,locations(j)),...
                dotWidth, probes(j) * ones(1,3), [], 2);
        end
        Screen('FillRect', screenparms.window, red, fixationPosition); %0*ones(3,2)
        
        % Present instructions
       % showtext(screenparms, textsize/3, 'Same or different?', 2, 250, -30); 
      %  showtext(screenparms, textsize/2, 'Same', 2, 300, -screenparms.rect(4)/4);
     %  showtext(screenparms, textsize/3, '(Press LEFT)', 2, 350, -screenparms.rect(4)/4);
      %  showtext(screenparms, textsize/2, 'Different', 2, 300, screenparms.rect(4)/4);
       % showtext(screenparms, textsize/3, '(Press RIGHT)', 2, 350, screenparms.rect(4)/4);

        WaitSecs(postNoiseTime);
        RTBox('clear'); % clear buffer and sync clocks before stimulus onset
        vbl = Screen('Flip', screenparms.window); 
        
        % Record response
        [cpuTime, buttonPress] = RTBox(timeout);  % computer time of button response
        FillScreen(screenparms);
        Screen('Flip', screenparms.window); 
        
        if ~isempty(cpuTime)
            rt(i, 1)   = (cpuTime(1) - vbl) * 1000;
        else
            rt(i, 1) = nan;
            buttonPress = '9';
        end
        
        
        if ~isempty(buttonPress)
            if ismember(buttonPress(1), {'1', '2'})
                response(i, 1) = 1;
            elseif ismember(buttonPress(1), {'3', '4'})
                response(i, 1) = 2;
            end
        else
            response(i, 1) = nan;
        end

        % Determine whether correct and display feedback
        if response(i,1) == sameTrial(i,1) && rt(i,1) < 5000 && ~isnan(response(i,1))  % their response is correct
            correctFlag(i,1) = 1;
            if feedbackWhenRight
                showtext(screenparms, textsize, feedback{2}, 2, 0, 0);
                Screen('Flip', screenparms.window); 
                WaitSecs(fbkDuration);
            end
            FillScreen(screenparms); 
            Screen('Flip', screenparms.window); 
            WaitSecs(citi);
        elseif response(i,1) ~= sameTrial(i,1) && rt(i,1) < 5000 && ~isnan(response(i,1)) % their response is incorrect
            correctFlag(i,1) = 0;
            if feedbackWhenWrong
                showtext(screenparms, textsize, feedback{1}, 2, 0, 0);
                Screen('Flip', screenparms.window); 
                WaitSecs(fbkDuration);
            end
            FillScreen(screenparms);
            Screen('Flip', screenparms.window);
            WaitSecs(citi);
        else
            correctFlag(i,1) = 9; 
            if feedbackWhenSlow
                showtext(screenparms, textsize, 'Too Slow!', 2, 0, 0);
                Screen('Flip', screenparms.window); 
                WaitSecs(fbkDuration);
            end
            FillScreen(screenparms); 
            Screen('Flip', screenparms.window); 
            WaitSecs(citi);
        end
        Priority(0);
        

        %% Insert a short break at 1/4, 1/2, and 3/4 trials
        if ismember(trialcnt, nTrialsPerBlock) 
            showtext(screenparms, 20, 'Take a short break. Press any button to continue', 1, 0, 0);
            
            % Compute accuracy on current block
            if bblocks == 1
                blkcorrect = correctFlag(1:end,1);
            else
                blkcorrect = correctFlag;
            end
            nblk = numel(blkcorrect);
            blkcorrect(isnan(blkcorrect),:) = [];
            blkcorrect(blkcorrect == 9,:) = []; 
            blkpercent = 100 * sum(blkcorrect)/nblk;
            showtext(screenparms, 20, sprintf('Accuracy = %4.2f percent correct in last block', blkpercent), 1, 100, 0);
            
            Screen('Flip', screenparms.window); 
            RTBox('clear'); % clear buffer and sync clocks before stimulus onset
            while ~any(RTBox('ButtonDown')); WaitSecs(0.01); end % Wait for any button press
            Screen('Flip', screenparms.window); 
        end
        trialcnt = trialcnt + 1;
        overallTrialCount = overallTrialCount + 1; 
    % end of trial loop
    end
    overallcorrect = [overallcorrect; correctFlag(1:end,1)];
    
    output = [output; blockStimlist response sameTrial... % stim1 stim2 response sameTrial?
                      correctFlag rt]; % cornerTrial? correct? rt
    
    if bblocks == nBlocks
        showtext(screenparms, 20, 'Preparing Output', 1, 0, 0);
        Screen('Flip', screenparms.window); 
    end
    
    %% Save data
    finaloutput = [repmat(subject, trialcnt-1,1),...
        repmat(bblocks, trialcnt-1, 1),...
        repmat(session, trialcnt-1,1),...
        (1:trialcnt-1)',...
        blockTrialMatrix,...
        output];
    
    dlmwrite(outputfile, finaloutput, '-append');
    
    % end of block loop
    disp(finaloutput)
end
showInstructions(screenparms, endImage, 'RTBox');
closeexp(screenparms) %% Close experiment

%% Check for bonus
ocNoTimeOut = overallcorrect(overallcorrect ~= 9);
overallAcc = sum(ocNoTimeOut)./numel(ocNoTimeOut);
fprintf('Overall Accuracy = %4.2f\n', overallAcc)

