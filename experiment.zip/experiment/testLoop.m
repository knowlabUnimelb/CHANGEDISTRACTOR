clear all
clc

load tempTest
overallTrialCount = 1; 

for bblocks = 1:nBlocks
    trialcnt = 1;
    for i = 1:nTrialsPerBlock
 targets = datasample(targetValues, trialMatrix(overallTrialCount,1), 'Replace', false);
        if isnan(trialMatrix(overallTrialCount, end)) && trialMatrix(overallTrialCount,2) ~= 0  % One change
             % Select change location at random
             
             probes = nan(1,numel(targets));
             while any(isnan(probes)) || anyDuplicates(probes)
                 if anyDuplicates(probes)
                 probes = nan(1,numel(targets));
                 targets = datasample(targetValues, trialMatrix(overallTrialCount,1), 'Replace', false);
                 end
                 changeLocation = datasample(1:numel(targets), 1);
                 probeCells = probeValues{targets(changeLocation) == targetValues};
                 probeCellValues = probeCells{trialMatrix(overallTrialCount,2)+1};
                 probes(1, changeLocation) = datasample(probeCellValues, 1);
                 probes(isnan(probes)) = targets(isnan(probes));
             end
        elseif ~isnan(trialMatrix(overallTrialCount, end)) % Two changes
            probes = nan(1,numel(targets));
            while any(isnan(probes)) || anyDuplicates(probes)
                if anyDuplicates(probes)
                probes = nan(1,numel(targets));
                targets = datasample(targetValues, trialMatrix(overallTrialCount,1), 'Replace', false);
                end
                changeLocation = datasample(1:numel(targets), 2, 'Replace', false);
                for tidx = 1:numel(changeLocation)
                    probeCells = probeValues{targets(changeLocation(tidx)) == targetValues};
                    probeCellValues = probeCells{trialMatrix(overallTrialCount,tidx+1)+1};
                    probes(1, changeLocation(tidx)) = datasample(probeCellValues, 1);
                end
                probes(isnan(probes)) = targets(isnan(probes));
            end
        else % no changes
            probes = targets; 
        end
        
        T{overallTrialCount} = targets;
        P{overallTrialCount} = probes;
        
                trialcnt = trialcnt + 1;
        overallTrialCount = overallTrialCount + 1
    % end of trial loop
    end
    
end